// =========================================================================
// FIRMWARE TEST TOÀN DIỆN ESP32-S3 N16R8:
// ĐỘNG CƠ BƯỚC NEMA 23 + DRIVER DM556 + ENCODER 3806 + CTHT HOME
// + ĐỒNG HỒ THỜI GIAN THỰC RTC DS3231 + 4 CẢM BIẾN QUANG TEMT6000 (ADC1)
//
// Phân bổ chân chuẩn 100% cho ESP32-S3 N16R8 (Tránh hoàn toàn GPIO 26-37):
//   - Trục 1 (Azimuth - Xoay Ngang)  : PUL=10, DIR=11, HOME=18, ENC A=6, ENC B=7
//   - Trục 2 (Elevation - Độ Ngửa)   : PUL=12, DIR=13, HOME=21, ENC A=16, ENC B=17
//   - I2C Bus (DS3231 + INA226)      : SDA=8, SCL=9, SQW/INT=47 (Có timeout chống treo)
//   - Cảm biến quang TEMT6000 (ADC1) : TOP=1, BOT=2, LFT=3, RGT=4
// =========================================================================

#include <Arduino.h>
#include <Preferences.h>
#include <Wire.h>
#include <WiFi.h>
#include <Firebase_ESP_Client.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>
#include <FastAccelStepper.h>
#include <driver/pcnt.h>
#include "config.h"
#include "param_registry.h"
#include "calibration_store.h"
#include "bench_wizard.h"

Preferences prefs;

// FastAccelStepper Hardware Pulse Generator
FastAccelStepperEngine engine = FastAccelStepperEngine();
FastAccelStepper *stepper1 = NULL;
FastAccelStepper *stepper2 = NULL;

// FreeRTOS Core 0 Task & Thread Safety
TaskHandle_t      telemetryTaskHandle = NULL;
SemaphoreHandle_t i2cMutex            = NULL;
volatile bool     telemetryDirty      = false;

void requestTelemetryPrint() {
  telemetryDirty = true;
}

// Firebase Objects
FirebaseData   fbdo;
FirebaseAuth   auth;
FirebaseConfig fbConfig;
unsigned long  lastFirebasePushTime = 0;

// -------------------------------------------------------------------------
// 1. CẤU HÌNH CHÂN NGOẠI VI CHO ESP32-S3 N16R8
// -------------------------------------------------------------------------
// Trục 1: Azimuth (Góc quay phương vị)
#define M1_PUL_PIN        10  // PUL+ Driver DM556 #1 (J1 Pin 16)
#define M1_DIR_PIN        11  // DIR+ Driver DM556 #1 (J1 Pin 17)
#define M1_HOME_SW_PIN    18  // Công tắc hành trình Home 1 (NO vào GPIO 18, COM vào GND - J1 Pin 11)
#define M1_ENC_A_PIN      6   // Pha A Encoder #1 (Dây Trắng - J1 Pin 6) -> MỚI ĐỔI (Tránh lỗi chân 14)
#define M1_ENC_B_PIN      7   // Pha B Encoder #1 (Dây Xanh Lá - J1 Pin 7) -> MỚI ĐỔI (Tránh lỗi chân 15)

// Trục 2: Elevation (Độ ngửa / Nâng hạ)
#define M2_PUL_PIN        12  // PUL+ Driver DM556 #2 (J1 Pin 18)
#define M2_DIR_PIN        13  // DIR+ Driver DM556 #2 (J1 Pin 19)
#define M2_HOME_SW_PIN    21  // Công tắc hành trình Home 2 (NO vào GPIO 21, COM vào GND - J3 Pin 18)
#define M2_ENC_A_PIN      16  // Pha A Encoder #2 (Dây Trắng - J1 Pin 9)
#define M2_ENC_B_PIN      17  // Pha B Encoder #2 (Dây Xanh Lá - J1 Pin 10)

// I2C Bus & RTC DS3231
#define I2C_SDA_PIN       8
#define I2C_SCL_PIN       9
#define DS3231_I2C_ADDR   0x68
#define DS3231_SQW_PIN    47  // Chân ngắt báo thức Alarm 1 (J3 Pin 17 - Hàng bên phải, ngay trên CTHT 2)

// 4 Cảm biến quang TEMT6000 (Chân ADC1 hoàn toàn độc lập với WiFi)
#define PIN_TEMT_TOP      1   // ADC1_CH0
#define PIN_TEMT_BOT      2   // ADC1_CH1
#define PIN_TEMT_LFT      3   // ADC1_CH2
#define PIN_TEMT_RGT      4   // ADC1_CH3

#define HOME_ACTIVE_LEVEL LOW // Chân kéo INPUT_PULLUP: Chạm Home = LOW

// Chiều quay cơ khí:
#define DIR_TOWARD_HOME   LOW   // Chiều tiến vào công tắc Home
#define DIR_AWAY_HOME     HIGH  // Chiều lùi ra xa công tắc Home

// -------------------------------------------------------------------------
// 2. THAM SỐ CƠ KHÍ & ENCODER & TỐC ĐỘ (600 PPR, HỘP SỐ 3:1)
// -------------------------------------------------------------------------
const float ENCODER_PPR       = 600.0f;                  // 600 xung/vòng
const float COUNTS_PER_REV    = 4.0f * ENCODER_PPR;      // 2400 counts / vòng ngắt 4X

// Tỷ số truyền cơ khí động cơ : tải = 3 : 1
const float GEAR_RATIO           = 3.0f;

// Driver DM556 thiết lập SW3=ON, SW8=ON -> 25600 xung/vòng động cơ (dòng đỉnh 3.2A, SW4=OFF half-current)
const float PULSES_PER_REV_MOTOR = 25600.0f;

// Số xung phát từ driver trên 1 độ quay của tấm pin (Tấm quay 360° = Động cơ quay 3 vòng = 76800 xung)
const float PULSES_PER_DEG_PANEL = (PULSES_PER_REV_MOTOR * GEAR_RATIO) / 360.0f; // 213.333 xung / độ tấm

// Tham số vị trí lắp đặt Encoder (ĐÍNH CHÍNH QUAN TRỌNG: Mặc định UNKNOWN cho tới khi chạy Bench B2)
enum EncoderLocation {
  ENCODER_LOC_UNKNOWN = 0, // Chưa xác nhận bằng Bench B2 (Tạm tính theo ENCODER_ON_LOAD: 0.15°/count)
  ENCODER_ON_LOAD     = 1, // ĐÃ CHỐT: Encoder 1:1 trên trục tải (trục tấm): 2400 count/vòng tấm = 0.15°/count, 32 xung/count
  ENCODER_ON_MOTOR    = 2  // ĐÃ CHỐT: Encoder trên trục động cơ (trước hộp số 3:1): 2400 count/vòng motor = 0.05°/count tấm
};

EncoderLocation encoderLocation = ENCODER_LOC_UNKNOWN; // Cần Bench B2 để chốt giá trị

// Độ phân giải góc tấm tính theo vị trí Encoder (Đọc động từ ParamRegistry)
inline float getDegPerCount() {
  int encLoc = ParamRegistry.getInt("ENCODER_ON_LOAD", (int)encoderLocation);
  float ppr = ParamRegistry.get("ENCODER_PPR_AZ", 600.0f);
  float gearRatio = ParamRegistry.get("GEAR_RATIO_AZ", 3.0f);
  float cpr = 4.0f * ppr;
  if (encLoc == ENCODER_ON_MOTOR) {
    return (360.0f / cpr) / gearRatio; // 0.05°/count nếu gắn trục motor
  }
  // Mặc định hoặc ENCODER_ON_LOAD: Gắn trên trục tấm pin (tải): 360° / 2400 = 0.15°/count
  return 360.0f / cpr; // 0.15°/count (KHÔNG chia tỉ số truyền!)
}

// Số xung phát tương ứng 1 count encoder (Đọc động từ ParamRegistry)
inline float getPulsesPerCount() {
  int encLoc = ParamRegistry.getInt("ENCODER_ON_LOAD", (int)encoderLocation);
  float ppr = ParamRegistry.get("ENCODER_PPR_AZ", 600.0f);
  float pulsesPerRev = ParamRegistry.get("E_PULSES_PER_REV_AZ", 25600.0f);
  float gearRatio = ParamRegistry.get("GEAR_RATIO_AZ", 3.0f);
  float cpr = 4.0f * ppr;
  if (encLoc == ENCODER_ON_MOTOR) {
    return pulsesPerRev / cpr; // 25600 / 2400 = 10.667 xung/count
  }
  return (pulsesPerRev * gearRatio) / cpr; // 76800 / 2400 = 32.0 xung/count
}

const float DEG_PER_COUNT        = 360.0f / COUNTS_PER_REV; // 0.15° / count danh định

// Hằng số hình học lắp đặt & La bàn địa lý (chuẩn theo solar_config.h)
const float CFG_G_AZ_HOME_SW_DEG  = 45.0f; // [G] Phương vị thực tế công tắc Home Azimuth (45° Đông Bắc)
const float CFG_H_AZ_OFFSET_DEG   = 0.0f;  // [H] Độ lệch lắp đặt thực địa (Offset hiệu chuẩn solar noon)
const float CFG_J_EL_HOME_SW_DEG  = 90.0f; // [J] Góc nâng epsilon tại công tắc Home Elevation (90° Zenith/Nằm ngang)

// Giới hạn mềm an toàn bảo vệ cơ học (Software Limits - đọc động từ ParamRegistry)
inline float getAzMaxSoftLimitDeg() { return ParamRegistry.get("SOFT_MAX_AZ", 270.0f); }
inline float getElMinSoftLimitDeg() { return ParamRegistry.get("L_EL_MIN_SOFT", 25.0f); }
inline float getElMaxSoftLimitDeg() { return ParamRegistry.get("SOFT_MAX_EL", 180.0f); }
#define CFG_I_AZ_MAX_SOFT_LIMIT_DEG (getAzMaxSoftLimitDeg())
#define CFG_L_EL_MIN_SOFT_LIMIT_DEG (getElMinSoftLimitDeg())
#define CFG_J_EL_MAX_SOFT_LIMIT_DEG (getElMaxSoftLimitDeg())

volatile int32_t encoderCount1 = 0;
volatile int32_t encoderCount2 = 0;
volatile uint32_t rawEdges1A   = 0; // Đếm cạnh xung riêng biệt Pha A Trục 1 (GPIO 6)
volatile uint32_t rawEdges1B   = 0; // Đếm cạnh xung riêng biệt Pha B Trục 1 (GPIO 7)
volatile uint32_t rawEdges2A   = 0; // Đếm cạnh xung riêng biệt Pha A Trục 2 (GPIO 16)
volatile uint32_t rawEdges2B   = 0; // Đếm cạnh xung riêng biệt Pha B Trục 2 (GPIO 17)
bool rawEncStream = false;          // Cờ bật/tắt in mức logic & so sánh song song mỗi 200ms

// Bộ đếm phần mềm 4X (Lookup Table 16 phần tử - phương pháp cũ đã chạy chuẩn)
DRAM_ATTR static const int8_t ENC_STATES[16] = {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};
volatile int32_t swEncoderCount1 = 0;
volatile int32_t swEncoderCount2 = 0;
volatile uint8_t swOldState1     = 0;
volatile uint8_t swOldState2     = 0;

bool invertEncoderDir1 = false;
bool invertEncoderDir2 = false;

void IRAM_ATTR isrEnc1A() {
  rawEdges1A++;
  uint8_t s = (digitalRead(M1_ENC_A_PIN) << 1) | digitalRead(M1_ENC_B_PIN);
  swOldState1 = ((swOldState1 << 2) | s) & 0x0F;
  int8_t diff = ENC_STATES[swOldState1];
  if (invertEncoderDir1) diff = -diff;
  swEncoderCount1 += diff;
}

void IRAM_ATTR isrEnc1B() {
  rawEdges1B++;
  uint8_t s = (digitalRead(M1_ENC_A_PIN) << 1) | digitalRead(M1_ENC_B_PIN);
  swOldState1 = ((swOldState1 << 2) | s) & 0x0F;
  int8_t diff = ENC_STATES[swOldState1];
  if (invertEncoderDir1) diff = -diff;
  swEncoderCount1 += diff;
}

void IRAM_ATTR isrEnc2A() {
  rawEdges2A++;
  uint8_t s = (digitalRead(M2_ENC_A_PIN) << 1) | digitalRead(M2_ENC_B_PIN);
  swOldState2 = ((swOldState2 << 2) | s) & 0x0F;
  int8_t diff = ENC_STATES[swOldState2];
  if (invertEncoderDir2) diff = -diff;
  swEncoderCount2 += diff;
}

void IRAM_ATTR isrEnc2B() {
  rawEdges2B++;
  uint8_t s = (digitalRead(M2_ENC_A_PIN) << 1) | digitalRead(M2_ENC_B_PIN);
  swOldState2 = ((swOldState2 << 2) | s) & 0x0F;
  int8_t diff = ENC_STATES[swOldState2];
  if (invertEncoderDir2) diff = -diff;
  swEncoderCount2 += diff;
}

bool liveEncoderMonitor = false;   // Chế độ Live Monitor hiển thị từng cạnh xung ngay lập tức (phím V)

// Tốc độ (Hz = steps/s) và Gia tốc (steps/s^2) phần cứng FastAccelStepper (Mặc định êm ái, an toàn, mô-men xoắn cao)
uint32_t manualSpeedHz    = 1200; // Tốc độ chạy tay (Hz) - tương đương ~350us của code cũ, chạy đầm, êm
uint32_t autoSpeedHz      = 1600; // Tốc độ Homing tự động (Hz)
uint32_t stepperAccel     = 2400; // Gia tốc (steps/s^2) - tạo dốc S-curve êm ái trong 0.5s, không giật giàn cơ
int stepsPerPress         = 400;  // Số bước mỗi lần bấm phím A/D (400 bước vừa phải như code 1 motor cũ)

// Thông số Homing 2 giai đoạn (Two-Stage Precision Homing: Fast -> Retract -> Creep)
const uint32_t HOME_FAST_SPEED_HZ  = 1200; // Giai đoạn 1: Tiếp cận nhanh vừa phải (Hz)
const uint32_t HOME_CREEP_SPEED_HZ = 200;  // Giai đoạn 3: Rà chậm tiếp xúc chính xác (Hz, sai số <= 1 bước)
const int32_t  HOME_RETRACT_STEPS  = 300;  // Giai đoạn 2: Lùi nhả switch (~1.5 vòng vi bước)

// -------------------------------------------------------------------------
// 3. VỊ TRÍ MẶC ĐỊNH M1 VÀ M2 (LƯU VĨNH VIỄN TRONG FLASH NVS)
// -------------------------------------------------------------------------
const int32_t INIT_DEFAULT_COUNTS_1 = 600;
const float   INIT_DEFAULT_DEG_1    = 90.0f;   // 600 counts * 0.15° = 90.0° góc giàn pin (khi Encoder ở tải)

const int32_t INIT_DEFAULT_COUNTS_2 = -389;
const float   INIT_DEFAULT_DEG_2    = -58.35f; // -389 counts * 0.15° = -58.35° góc giàn pin (khi Encoder ở tải)

int32_t defaultCount1 = INIT_DEFAULT_COUNTS_1;
float   defaultDeg1   = INIT_DEFAULT_DEG_1;
bool    hasDefault1   = true;

int32_t defaultCount2 = INIT_DEFAULT_COUNTS_2;
float   defaultDeg2   = INIT_DEFAULT_DEG_2;
bool    hasDefault2   = true;

enum MotorState {
  STATE_IDLE = 0,
  STATE_MANUAL_TOWARD_HOME,
  STATE_MANUAL_AWAY_HOME,
  STATE_AUTO_HOMING,
  STATE_AUTO_SEEK_DEFAULT
};

MotorState stateM1 = STATE_IDLE;
MotorState stateM2 = STATE_IDLE;
int activeAxis = 1;

// Trạng thái Bám quang tự động (Optical Tracking) & Lọc tín hiệu
bool autoOpticalTracking = false;
unsigned long lastOpticalTrackTime = 0;
const float OPTICAL_NORM_DEADBAND   = 0.05f; // Vùng chết chuẩn hóa: sai số <= 5% (0.05) coi như đã cân bằng hoàn hảo
const int   OPTICAL_NIGHT_THRESHOLD = 50;    // Ngưỡng trời tối (dưới 50 ADC counts -> dừng quay tiết kiệm điện)
const float EMA_ALPHA               = 0.25f; // Hệ số lọc số mũ EMA (0.25: mượt mà, triệt tiêu 100% rung 1-count)

// Biến lưu trạng thái trước đó để kiểm tra thay đổi
int32_t    prevCount1 = -999999, prevCount2 = -999999;
bool       prevHome1  = false,   prevHome2  = false;
MotorState prevState1 = (MotorState)-1, prevState2 = (MotorState)-1;
int        prevActiveAxis = -1;
unsigned long lastPrintTime = 0;

// -------------------------------------------------------------------------
// 4. BỘ ĐẾM XUNG PHẦN CỨNG PCNT (ESP32-S3 SILICON 4X QUADRATURE DECODER)
// -------------------------------------------------------------------------
// Thay thế ngắt GPIO ISR mềm: Đếm 100% bằng phần cứng silicon PCNT trên ESP32-S3.
// Tích hợp Hardware Glitch Filter (200 chu kỳ APB = 2.5us) triệt tiêu hoàn toàn nhiễu DM556!
static int16_t lastPcntVal1 = 0;
static int16_t lastPcntVal2 = 0;

void initPcntEncoder(pcnt_unit_t unit, int pinA, int pinB) {
  pcnt_config_t pcnt_config_a = {
    .pulse_gpio_num = pinA,
    .ctrl_gpio_num  = pinB,
    .lctrl_mode     = PCNT_MODE_REVERSE,
    .hctrl_mode     = PCNT_MODE_KEEP,
    .pos_mode       = PCNT_COUNT_DEC,
    .neg_mode       = PCNT_COUNT_INC,
    .counter_h_lim  = 32000,
    .counter_l_lim  = -32000,
    .unit           = unit,
    .channel        = PCNT_CHANNEL_0,
  };
  pcnt_unit_config(&pcnt_config_a);

  pcnt_config_t pcnt_config_b = {
    .pulse_gpio_num = pinB,
    .ctrl_gpio_num  = pinA,
    .lctrl_mode     = PCNT_MODE_REVERSE,
    .hctrl_mode     = PCNT_MODE_KEEP,
    .pos_mode       = PCNT_COUNT_INC,
    .neg_mode       = PCNT_COUNT_DEC,
    .counter_h_lim  = 32000,
    .counter_l_lim  = -32000,
    .unit           = unit,
    .channel        = PCNT_CHANNEL_1,
  };
  pcnt_unit_config(&pcnt_config_b);

  // Bộ lọc phần cứng Glitch Filter (80 chu kỳ clock APB 80MHz = 1000 ns = 1.0 micro-giây)
  // Nhỏ hơn 1/10 độ rộng xung nhỏ nhất của Encoder ở tốc độ tối đa
  pcnt_set_filter_value(unit, 80);
  pcnt_filter_enable(unit);

  pcnt_counter_pause(unit);
  pcnt_counter_clear(unit);
  pcnt_counter_resume(unit);
}

int32_t getEncoderCount1() {
  int16_t hw = 0;
  pcnt_get_counter_value(PCNT_UNIT_0, &hw);
  int16_t diff = hw - lastPcntVal1;
  lastPcntVal1 = hw;
  if (invertEncoderDir1) diff = -diff;
  encoderCount1 += diff;
  return encoderCount1;
}

int32_t getEncoderCount2() {
  int16_t hw = 0;
  pcnt_get_counter_value(PCNT_UNIT_1, &hw);
  int16_t diff = hw - lastPcntVal2;
  lastPcntVal2 = hw;
  if (invertEncoderDir2) diff = -diff;
  encoderCount2 += diff;
  return encoderCount2;
}

void resetEncoder1(int32_t val = 0) {
  pcnt_counter_pause(PCNT_UNIT_0);
  pcnt_counter_clear(PCNT_UNIT_0);
  lastPcntVal1 = 0;
  encoderCount1 = val;
  swEncoderCount1 = val;
  swOldState1 = (digitalRead(M1_ENC_A_PIN) << 1) | digitalRead(M1_ENC_B_PIN);
  pcnt_counter_resume(PCNT_UNIT_0);
}

void resetEncoder2(int32_t val = 0) {
  pcnt_counter_pause(PCNT_UNIT_1);
  pcnt_counter_clear(PCNT_UNIT_1);
  lastPcntVal2 = 0;
  encoderCount2 = val;
  swEncoderCount2 = val;
  swOldState2 = (digitalRead(M2_ENC_A_PIN) << 1) | digitalRead(M2_ENC_B_PIN);
  pcnt_counter_resume(PCNT_UNIT_1);
}

// Hàm trả về góc thực tế của GIÀN PIN (Đọc theo tham số encoderLocation, KHÔNG chia 3 nếu ở tải!)
float getAngleDeg1()      { return (float)getEncoderCount1() * getDegPerCount(); }
float getAngleDeg2()      { return (float)getEncoderCount2() * getDegPerCount(); }

// Hàm trả về góc trên TRỤC ĐỘNG CƠ phục vụ chẩn đoán
float getMotorAngleDeg1() {
  if (encoderLocation == ENCODER_ON_LOAD) return (float)getEncoderCount1() * getDegPerCount() * GEAR_RATIO;
  return (float)getEncoderCount1() * DEG_PER_COUNT;
}
float getMotorAngleDeg2() {
  if (encoderLocation == ENCODER_ON_LOAD) return (float)getEncoderCount2() * getDegPerCount() * GEAR_RATIO;
  return (float)getEncoderCount2() * DEG_PER_COUNT;
}

// Góc La bàn địa lý Azimuth (tính từ Bắc = 0° theo chiều KĐH: Bắc 0°, Đông 90°, Nam 180°, Tây 270°)
float getCompassAzimuth() {
  float az = CFG_G_AZ_HOME_SW_DEG + CFG_H_AZ_OFFSET_DEG + getAngleDeg1();
  while (az >= 360.0f) az -= 360.0f;
  while (az < 0.0f)    az += 360.0f;
  return az;
}

// Góc nâng thực tế của giàn pin (Elevation/Epsilon: 0° = mặt đất, 90° = đỉnh trời/zenith)
float getElevationEpsilon() {
  return CFG_J_EL_HOME_SW_DEG + getAngleDeg2();
}

// -------------------------------------------------------------------------
// 5. BỘ LỌC DEBOUNCE CHỐNG DỘI TIẾP ĐIỂM & CHỐNG NHIỄU XUNG BĂM DM556
// -------------------------------------------------------------------------
// Yêu cầu tín hiệu mức LOW phải duy trì LIÊN TỤC 25ms (Continuous Window).
// Mọi gai xung nhiễu điện từ (EMI) ngắt quãng do băm dòng động cơ sẽ bị triệt tiêu 100%.
bool isHome1Triggered() {
  static bool debouncedState1 = false;
  static unsigned long lowStartTime1 = 0;
  static unsigned long highStartTime1 = 0;
  const unsigned long DEBOUNCE_MS = 25;

  bool isRawLow = (digitalRead(M1_HOME_SW_PIN) == HOME_ACTIVE_LEVEL);

  if (isRawLow) {
    highStartTime1 = 0;
    if (!debouncedState1) {
      if (lowStartTime1 == 0) {
        lowStartTime1 = millis();
      } else if (millis() - lowStartTime1 >= DEBOUNCE_MS) {
        debouncedState1 = true;
      }
    }
  } else {
    lowStartTime1 = 0;
    if (debouncedState1) {
      if (highStartTime1 == 0) {
        highStartTime1 = millis();
      } else if (millis() - highStartTime1 >= DEBOUNCE_MS) {
        debouncedState1 = false;
      }
    }
  }
  return debouncedState1;
}

bool isHome2Triggered() {
  static bool debouncedState2 = false;
  static unsigned long lowStartTime2 = 0;
  static unsigned long highStartTime2 = 0;
  const unsigned long DEBOUNCE_MS = 25;

  bool isRawLow = (digitalRead(M2_HOME_SW_PIN) == HOME_ACTIVE_LEVEL);

  if (isRawLow) {
    highStartTime2 = 0;
    if (!debouncedState2) {
      if (lowStartTime2 == 0) {
        lowStartTime2 = millis();
      } else if (millis() - lowStartTime2 >= DEBOUNCE_MS) {
        debouncedState2 = true;
      }
    }
  } else {
    lowStartTime2 = 0;
    if (debouncedState2) {
      if (highStartTime2 == 0) {
        highStartTime2 = millis();
      } else if (millis() - highStartTime2 >= DEBOUNCE_MS) {
        debouncedState2 = false;
      }
    }
  }
  return debouncedState2;
}

// Đọc trực tiếp không trễ (phục vụ ngắt khẩn cấp hoặc rà chính xác)
bool isHome1Raw() { return (digitalRead(M1_HOME_SW_PIN) == HOME_ACTIVE_LEVEL); }
bool isHome2Raw() { return (digitalRead(M2_HOME_SW_PIN) == HOME_ACTIVE_LEVEL); }

// -------------------------------------------------------------------------
// 5. GIAO TIẾP I2C & ĐỌC ĐỒNG HỒ RTC DS3231 (TỰ ĐỘNG KHÔNG CẦN LIB NGOÀI)
// -------------------------------------------------------------------------
uint8_t decToBcd(uint8_t val) { return ((val / 10 * 16) + (val % 10)); }
uint8_t bcdToDec(uint8_t val) { return ((val / 16 * 10) + (val % 16)); }

bool readDS3231(int &year, int &month, int &day, int &hour, int &minute, int &second, float &tempC) {
  if (i2cMutex && xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(50)) != pdTRUE) return false;

  Wire.beginTransmission(DS3231_I2C_ADDR);
  Wire.write(0x00); // Bắt đầu đọc từ thanh ghi giây 0x00
  if (Wire.endTransmission() != 0) {
    if (i2cMutex) xSemaphoreGive(i2cMutex);
    return false;
  }

  Wire.requestFrom((uint8_t)DS3231_I2C_ADDR, (uint8_t)7);
  if (Wire.available() < 7) {
    if (i2cMutex) xSemaphoreGive(i2cMutex);
    return false;
  }

  second = bcdToDec(Wire.read() & 0x7F);
  minute = bcdToDec(Wire.read());
  hour   = bcdToDec(Wire.read() & 0x3F);
  Wire.read(); // Bỏ qua day of week
  day    = bcdToDec(Wire.read());
  month  = bcdToDec(Wire.read() & 0x1F);
  year   = 2000 + bcdToDec(Wire.read());

  // Đọc cảm biến nhiệt độ tích hợp trong chip DS3231 (Thanh ghi 0x11, 0x12)
  Wire.beginTransmission(DS3231_I2C_ADDR);
  Wire.write(0x11);
  if (Wire.endTransmission() == 0) {
    Wire.requestFrom((uint8_t)DS3231_I2C_ADDR, (uint8_t)2);
    if (Wire.available() >= 2) {
      int8_t msb = Wire.read();
      uint8_t lsb = Wire.read();
      tempC = (float)msb + ((lsb >> 6) * 0.25f);
    }
  }
  if (i2cMutex) xSemaphoreGive(i2cMutex);
  return true;
}

bool writeDS3231(int year, int month, int day, int hour, int minute, int second) {
  if (i2cMutex && xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(100)) != pdTRUE) return false;

  Wire.beginTransmission(DS3231_I2C_ADDR);
  Wire.write(0x00); // Thanh ghi giay 0x00
  Wire.write(decToBcd(second));
  Wire.write(decToBcd(minute));
  Wire.write(decToBcd(hour));
  Wire.write(decToBcd(1)); // Thu trong tuan
  Wire.write(decToBcd(day));
  Wire.write(decToBcd(month));
  Wire.write(decToBcd(year >= 2000 ? year - 2000 : year));
  byte err = Wire.endTransmission();

  if (i2cMutex) xSemaphoreGive(i2cMutex);
  return (err == 0);
}

void scanI2CBus() {
  if (i2cMutex && xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(500)) != pdTRUE) {
    Serial.println(">> [I2C SCANNER] Bus I2C dang ban boi tac vu khac!");
    return;
  }

  Serial.println(">> [I2C SCANNER] Bat dau quet bus I2C (SDA: GPIO 8, SCL: GPIO 9)...");
  int nDevices = 0;
  for (byte address = 1; address < 127; ++address) {
    Wire.beginTransmission(address);
    byte error = Wire.endTransmission();
    if (error == 0) {
      Serial.printf("   [+] Tim thay thiet bi tai 0x%02X: ", address);
      if (address == 0x68) Serial.print("RTC DS3231 [CHIP CHINH]");
      else if (address == 0x57 || address == 0x50) Serial.print("EEPROM AT24C32 (tren module RTC)");
      else if (address == 0x40) Serial.print("INA226 #1 (Tam Xoay Tracker)");
      else if (address == 0x41) Serial.print("INA226 #2 (Tam Co Dinh Static)");
      else Serial.print("Thiet bi I2C");
      Serial.println();
      nDevices++;
    }
  }
  if (nDevices == 0) {
    Serial.println("   [!] Khong tim thay thiet bi I2C nao tren bus.");
    Serial.println("   -> Kiem tra: Day VCC 3.3V, GND, SDA (G8) va SCL (G9) co tiep xuc tot khong.");
  } else {
    Serial.printf(">> Tong cong tim thay: %d thiet bi I2C hoat dong tot!\n", nDevices);
  }
  Serial.println();
  if (i2cMutex) xSemaphoreGive(i2cMutex);
}

void printRTCStatus() {
  int y, m, d, hh, mm, ss;
  float tC = 0.0f;
  if (readDS3231(y, m, d, hh, mm, ss, tC)) {
    Serial.printf(">> [RTC DS3231 LIVE] Gio: %02d:%02d:%02d | Ngay: %02d/%02d/%04d | Nhiet do: %.2f °C\n\n",
                  hh, mm, ss, d, m, y, tC);
  } else {
    Serial.println(">> [RTC DS3231] Chua ket noi duoc DS3231 tai dia chi 0x68.\n");
  }
}

// -------------------------------------------------------------------------
// 6. ĐỌC 4 CẢM BIẾN QUANG TEMT6000 & THUẬT TOÁN BÁM SÁNG
// (Cấu trúc OpticalData đã được định nghĩa chuẩn trong config.h)

OpticalData latestOpticalData = {0, 0, 0, 0, 0, 0, 0.0f, 0.0f, 0};

// Bộ nhớ đệm cho bộ lọc EMA (Exponential Moving Average)
static float emaTop = 0.0f;
static float emaBot = 0.0f;
static float emaLft = 0.0f;
static float emaRgt = 0.0f;
static bool  emaInitialized = false;

// Bộ nhớ đệm cửa sổ 3 mẫu cho bộ lọc trung vị (Median Filter chống xung gai đột ngột)
static uint16_t medBufTop[3] = {0, 0, 0};
static uint16_t medBufBot[3] = {0, 0, 0};
static uint16_t medBufLft[3] = {0, 0, 0};
static uint16_t medBufRgt[3] = {0, 0, 0};
static uint8_t  medIdx = 0;

inline uint16_t getMedian3(uint16_t a, uint16_t b, uint16_t c) {
  if ((a <= b && b <= c) || (c <= b && b <= a)) return b;
  if ((b <= a && a <= c) || (c <= a && a <= b)) return a;
  return c;
}

OpticalData readOpticalSensors() {
  // 1. Oversampling 64 mẫu trong đúng 20 ms (2 chu kỳ điện lưới 50Hz / chớp đèn 100Hz)
  const int SAMPLES = 64;
  uint32_t sumTop = 0, sumBot = 0, sumLft = 0, sumRgt = 0;

  for (int i = 0; i < SAMPLES; i++) {
    sumTop += analogRead(PIN_TEMT_TOP);
    sumBot += analogRead(PIN_TEMT_BOT);
    sumLft += analogRead(PIN_TEMT_LFT);
    sumRgt += analogRead(PIN_TEMT_RGT);
    delayMicroseconds(260); // Đọc 4 kênh ADC (~50us) + delay (260us) = ~310us * 64 ≈ 20 ms
  }

  uint16_t avgSampleTop = sumTop / SAMPLES;
  uint16_t avgSampleBot = sumBot / SAMPLES;
  uint16_t avgSampleLft = sumLft / SAMPLES;
  uint16_t avgSampleRgt = sumRgt / SAMPLES;

  // 2. Bộ lọc trung vị (Median Filter 3 mẫu) triệt tiêu hoàn toàn xung gai đột biến
  medBufTop[medIdx] = avgSampleTop;
  medBufBot[medIdx] = avgSampleBot;
  medBufLft[medIdx] = avgSampleLft;
  medBufRgt[medIdx] = avgSampleRgt;
  medIdx = (medIdx + 1) % 3;

  uint16_t medTop = getMedian3(medBufTop[0], medBufTop[1], medBufTop[2]);
  uint16_t medBot = getMedian3(medBufBot[0], medBufBot[1], medBufBot[2]);
  uint16_t medLft = getMedian3(medBufLft[0], medBufLft[1], medBufLft[2]);
  uint16_t medRgt = getMedian3(medBufRgt[0], medBufRgt[1], medBufRgt[2]);

  // 3. Bộ lọc số mũ EMA (Exponential Moving Average, alpha = 0.25) làm mượt phẳng tín hiệu
  if (!emaInitialized) {
    emaTop = medTop; emaBot = medBot; emaLft = medLft; emaRgt = medRgt;
    emaInitialized = true;
  } else {
    emaTop = EMA_ALPHA * medTop + (1.0f - EMA_ALPHA) * emaTop;
    emaBot = EMA_ALPHA * medBot + (1.0f - EMA_ALPHA) * emaBot;
    emaLft = EMA_ALPHA * medLft + (1.0f - EMA_ALPHA) * emaLft;
    emaRgt = EMA_ALPHA * medRgt + (1.0f - EMA_ALPHA) * emaRgt;
  }

  OpticalData data;
  data.top = (int)(emaTop + 0.5f);
  data.bot = (int)(emaBot + 0.5f);
  data.lft = (int)(emaLft + 0.5f);
  data.rgt = (int)(emaRgt + 0.5f);
  data.diffAz = data.lft - data.rgt;
  data.diffEl = data.top - data.bot;
  data.avg    = (data.top + data.bot + data.lft + data.rgt) / 4;

  // 4. Chuẩn hóa sai số quang học: (L - R)/(L + R) và (T - B)/(T + B)
  float sumAz = (float)(data.lft + data.rgt);
  float sumEl = (float)(data.top + data.bot);

  data.normDiffAz = (sumAz > 20.0f) ? ((float)data.diffAz / sumAz) : 0.0f;
  data.normDiffEl = (sumEl > 20.0f) ? ((float)data.diffEl / sumEl) : 0.0f;

  latestOpticalData = data;
  return data;
}

void printOpticalSensors() {
  OpticalData opt = readOpticalSensors();
  Serial.printf(">> [TEMT6000 FILTERED] TOP: %4d | BOT: %4d | LFT: %4d | RGT: %4d | AVG: %4d\n",
                opt.top, opt.bot, opt.lft, opt.rgt, opt.avg);
  Serial.printf("   [CHUAN HOA] dAZ_norm: %+6.3f (%+5.1f%%) | dEL_norm: %+6.3f (%+5.1f%%) | Vung chet: ±%.1f%%\n",
                opt.normDiffAz, opt.normDiffAz * 100.0f,
                opt.normDiffEl, opt.normDiffEl * 100.0f,
                OPTICAL_NORM_DEADBAND * 100.0f);
  Serial.printf("   -> CHE DO BAM QUANG [O]: %s\n",
                autoOpticalTracking ? "DANG BAT (ON) - Dieu khien ti le Proportional"
                                    : "DANG TAT (OFF) - Hay bam phim [O] tren ban phim de BAT!");
  if (opt.avg < OPTICAL_NIGHT_THRESHOLD) {
    Serial.printf("   [!] CHU Y: Do sang trung binh AVG=%d < %d (Nguong toi). Can soi den sang hon de he thong bat dau quay!\n",
                  opt.avg, OPTICAL_NIGHT_THRESHOLD);
  } else if (fabs(opt.normDiffAz) <= OPTICAL_NORM_DEADBAND && fabs(opt.normDiffEl) <= OPTICAL_NORM_DEADBAND) {
    Serial.printf("   [i] CAN BANG: Ca 2 truc deu nam trong vung chet (<= %.1f%%) -> Gian pin dang can bang hoan hao.\n",
                  OPTICAL_NORM_DEADBAND * 100.0f);
  } else {
    Serial.printf("   [+] CO LECH SANG: dAZ=%+5.1f%%, dEL=%+5.1f%% -> Dong co se quay TI LE theo do lech!\n",
                  opt.normDiffAz * 100.0f, opt.normDiffEl * 100.0f);
  }
}

// -------------------------------------------------------------------------
// 7. IN TELEMETRY VÀ MENU
// -------------------------------------------------------------------------
const char* getStateStr(MotorState s) {
  switch (s) {
    case STATE_IDLE:               return "DUNG";
    case STATE_MANUAL_TOWARD_HOME: return "CHAY-HOME";
    case STATE_MANUAL_AWAY_HOME:   return "CHAY-XA";
    case STATE_AUTO_HOMING:        return "AUTO-HOMING";
    case STATE_AUTO_SEEK_DEFAULT:  return "SEEK-M(AUTO)";
    default:                       return "UNKNOWN";
  }
}

void printTelemetryIfChanged() {
  bool curHome1 = isHome1Triggered();
  bool curHome2 = isHome2Triggered();
  
  bool m1Running = (stateM1 != STATE_IDLE) || (stepper1 && stepper1->isRunning());
  bool m2Running = (stateM2 != STATE_IDLE) || (stepper2 && stepper2->isRunning());

  // Chỉ in khi:
  // - Trục đang chạy: theo dõi từng xung
  // - Trục đứng yên: chỉ cập nhật nếu lệch >= 2 counts (chống rung lắc 1-bit nhấp nháy 0<->1 khi trục kia chạy)
  bool enc1Changed  = m1Running ? (encoderCount1 != prevCount1) : (abs(encoderCount1 - prevCount1) >= 2);
  bool enc2Changed  = m2Running ? (encoderCount2 != prevCount2) : (abs(encoderCount2 - prevCount2) >= 2);
  bool home1Changed = (curHome1 != prevHome1);
  bool home2Changed = (curHome2 != prevHome2);
  bool stateChanged = (stateM1 != prevState1) || (stateM2 != prevState2);
  bool axisChanged  = (activeAxis != prevActiveAxis);

  bool isChanged = enc1Changed || enc2Changed || home1Changed || home2Changed || stateChanged || axisChanged;

  if (isChanged) {
    unsigned long minInterval = (m1Running || m2Running) ? 100 : 250;
    if (millis() - lastPrintTime >= minInterval) {
      lastPrintTime = millis();

      if (home1Changed) {
        Serial.println(curHome1 ? "\n>> [CTHT 1 TRIGGERED] Cong tac 1 (GPIO 18) DANG CHAM (LOW)!"
                                : "\n>> [CTHT 1 RELEASED] Cong tac 1 (GPIO 18) DA NHA (HIGH)!");
      }
      if (home2Changed) {
        Serial.println(curHome2 ? "\n>> [CTHT 2 TRIGGERED] Cong tac 2 (GPIO 21) DANG CHAM (LOW)!"
                                : "\n>> [CTHT 2 RELEASED] Cong tac 2 (GPIO 21) DA NHA (HIGH)!");
      }

      prevCount1     = encoderCount1;
      prevCount2     = encoderCount2;
      prevHome1      = curHome1;
      prevHome2      = curHome2;
      prevState1     = stateM1;
      prevState2     = stateM2;
      prevActiveAxis = activeAxis;

      float curPhi = getAngleDeg1();
      float compAz = getCompassAzimuth();
      float curEps = getElevationEpsilon();

      Serial.printf("[M1-AZ%s] Phi: %+6.2f° (La ban: %5.1f°) | Cnt: %6ld | CTHT: %-4s | Def: %+.1f° | TT: %-11s\n",
                    (activeAxis == 1) ? "*" : " ",
                    curPhi, compAz, encoderCount1,
                    curHome1 ? "CHAM" : "HO",
                    hasDefault1 ? defaultDeg1 : 0.0f,
                    getStateStr(stateM1));

      Serial.printf("[M2-EL%s] Epsilon: %5.1f° (Ngua: %+5.1f°) | Cnt: %6ld | CTHT: %-4s | Def: %+.1f° | TT: %-11s\n",
                    (activeAxis == 2) ? "*" : " ",
                    curEps, getAngleDeg2(), encoderCount2,
                    curHome2 ? "CHAM" : "HO",
                    hasDefault2 ? defaultDeg2 : 0.0f,
                    getStateStr(stateM2));
    }
  }
}

// -------------------------------------------------------------------------
// 8. ĐỒNG BỘ TELEMETRY LÊN FIREBASE REALTIME DATABASE (WEB DASHBOARD)
// -------------------------------------------------------------------------
void pushTelemetryToFirebase() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!Firebase.ready()) return;

  OpticalData opt = latestOpticalData;
  if (opt.avg == 0) {
    opt = readOpticalSensors();
  }

  float curPhi = getAngleDeg1();
  float curEpsilon = getElevationEpsilon();
  float compassAz = getCompassAzimuth();

  FirebaseJson trk;
  trk.set("phi", curPhi);
  trk.set("epsilon", curEpsilon);
  trk.set("azimuthAngle", compassAz);
  trk.set("elevationAngle", curEpsilon);
  trk.set("azEncoder", encoderCount1);
  trk.set("elEncoder", encoderCount2);
  trk.set("encoderPulses", encoderCount1);

  trk.set("ldrTop", opt.top);
  trk.set("ldrBottom", opt.bot);
  trk.set("ldrLeft", opt.lft);
  trk.set("ldrRight", opt.rgt);
  trk.set("normDiffAz", opt.normDiffAz);
  trk.set("normDiffEl", opt.normDiffEl);

  bool h1 = isHome1Triggered();
  bool h2 = isHome2Triggered();
  trk.set("limitHome", h1);
  trk.set("limitHome2", h2);

  bool isMoving = (stateM1 != STATE_IDLE || stateM2 != STATE_IDLE || (stepper1 && stepper1->isRunning()) || (stepper2 && stepper2->isRunning()));
  trk.set("mode", autoOpticalTracking ? "AUTO" : "MANUAL");
  trk.set("state", isMoving ? "MOVE" : (autoOpticalTracking ? "TRACKING" : "IDLE"));
  trk.set("status", isMoving ? "MOVE" : "TRACKING_ACTIVE");
  trk.set("activeAlgorithm", "PSO_FUZZY_PID");
  trk.set("lastUpdate", (double)millis());
  trk.set("online", true);
  trk.set("source", "device"); // Cờ bảo mật xác nhận dữ liệu từ thiết bị thật

  // Đọc RTC an toàn qua Mutex
  int y, m, d, hh, mm, ss;
  float tC = 0.0f;
  if (readDS3231(y, m, d, hh, mm, ss, tC)) {
    char timeStr[32];
    snprintf(timeStr, sizeof(timeStr), "%02d:%02d:%02d %02d/%02d/%04d", hh, mm, ss, d, m, y);
    trk.set("rtcTime", timeStr);
    trk.set("rtcTemp", tC);
  }

  Firebase.RTDB.updateNode(&fbdo, "/solar/tracking", &trk);
}

// -------------------------------------------------------------------------
// 9. FREE-RTOS TASK: CHẠY ĐỘC LẬP TRÊN CORE 0 (SERIAL TELEMETRY + FIREBASE)
// -------------------------------------------------------------------------
void telemetryTask(void *pvParameters) {
  unsigned long lastFbPushTime = 0;
  unsigned long lastTelPrintTime = 0;

  for (;;) {
    unsigned long now = millis();

    // 1. In Telemetry qua Serial Monitor (Core 0 chịu trách nhiệm, không bao giờ chặn Core 1)
    if (telemetryDirty || (now - lastTelPrintTime >= 100)) {
      telemetryDirty = false;
      lastTelPrintTime = now;
      printTelemetryIfChanged();
    }

    // 2. Đẩy Telemetry lên Firebase RTDB mỗi 1000ms trên Core 0
    if (now - lastFbPushTime >= 1000) {
      lastFbPushTime = now;
      pushTelemetryToFirebase();
    }

    vTaskDelay(pdMS_TO_TICKS(20)); // Nhường CPU 20ms cho WiFi / TCP-IP stack trên Core 0
  }
}

void printMenu() {
  Serial.println("=======================================================");
  Serial.println("  HE THONG TEST ESP32-S3: 2 TRUC NEMA 23 + RTC + OPTICAL");
  Serial.println("=======================================================");
  Serial.printf(" >> TRUC DANG CHON DIEU KHIEN: TRUC [%d] (%s)\n",
                activeAxis, (activeAxis == 1) ? "AZIMUTH - GOC QUAY" : "ELEVATION - DO NGUA");
  Serial.println("-------------------------------------------------------");
  Serial.println(" [1] : Chuyen sang dieu khien TRUC 1 (Azimuth - Xoay Ngang)");
  Serial.println(" [2] : Chuyen sang dieu khien TRUC 2 (Elevation - Do Ngua)");
  Serial.println("-------------------------------------------------------");
  Serial.println(" PHIM DIEU KHIEN CHUYEN DONG (CHO TRUC DANG CHON):");
  Serial.println("   [A] : Quay buoc ve huong HOME (Cham Home tu dung)");
  Serial.println("   [D] : Quay buoc ra xa HOME");
  Serial.println("   [Q] : Quay LIEN TUC ve huong HOME (Cham Home tu dung)");
  Serial.println("   [E] : Quay LIEN TUC ra xa HOME");
  Serial.println("   [M] : GHI DE GOC HIEN TAI LAM MOC MAC DINH (Luu Flash NVS)");
  Serial.println("   [G] : AUTO FAST HOMING CHO TRUC DANG CHON (Home -> Moc mac dinh)");
  Serial.println("   [0] : Reset truc tiep goc hien tai ve 0.0°");
  Serial.println("   [I] : Dao chieu dem Encoder (+/-)");
  Serial.println("-------------------------------------------------------");
  Serial.println(" PHIM NONG DUAL, CHAN DOAN & TIN HIEU:");
  Serial.println("   [H]       : DUAL AUTO HOMING: CA 2 TRUC VE HOME ROI VE MAC DINH");
  Serial.println("   [V]       : BAT / TAT LIVE ENCODER MONITOR (Hien thi tung xung khi xoay tay)");
  Serial.println("   [T]       : DIAGNOSTIC (Kiem tra muc dien ap logic tat ca cac chan & ngat)");
  Serial.println("   [K]       : BAT / TAT STREAM MUC LOGIC THO & DEM CANH PHA A/B (200ms)");
  Serial.println("   [O]       : BAT / TAT CHE DO TU DONG BAM HUONG ANH SANG (OPTICAL)");
  Serial.println("   [L]       : DOC GIA TRI 4 CAM BIEN QUANG TEMT6000 (LIVE ADC)");
  Serial.println("   [C]       : DOC DONG HO THOI GIAN THUC RTC DS3231 & QUET I2C");
  Serial.println("   [+] / [-] : Tang / Giam so buoc moi lan bam A/D (+/- 100 buoc)");
  Serial.println("   [>] / [<] : Tang / Giam toc do chay tay ([.] / [,])");
  Serial.println("   []] / [[] : Tang / Giam toc do Auto Homing (Delay us)");
  Serial.println("   [Space]/[X]: DUNG KHAN CAP TOAN BO DONG CO");
  Serial.println("   [R]       : HIEN THI LAI MENU NAY");
  Serial.println("-------------------------------------------------------");
  Serial.println(" LENH BENCHMARK & HIEU CHUAN (PARAM REGISTRY & FLASH NVS):");
  Serial.println("   params                 : In toan bo bang 38 tham so he thong");
  Serial.println("   set <TEN> <GIATRI>     : Cap nhat thu cong tham so (Kiem tra min/max)");
  Serial.println("   rollback <TEN>         : Khoi phuc gia tri truoc do cua tham so");
  Serial.println("   calib save             : Luu bang tham so vao Flash NVS (kem CRC32)");
  Serial.println("   calib load             : Nap lai bang tham so tu Flash NVS");
  Serial.println("   calib reset            : Xoa trang NVS, ve tham so mac dinh");
  Serial.println("   calib export / export  : Xuat JSON cau hinh (Chuan Firebase)");
  Serial.println("-------------------------------------------------------");
  Serial.println(" QUY TRINH KIEM CHUAN BENCH WIZARD & KHOA AN TOAN (GATING):");
  Serial.println("   bench                  : Hien thi bang trang thai 16 buoc kiem chuan B0-B15");
  Serial.println("   bench all              : Chay toan bo quy trinh tu B0 den B15");
  Serial.println("   bench <N>              : Chay buoc kiem chuan cu the (Vi du: bench 2)");
  Serial.println("   y / n                  : Dong y (Y) hoac Bo qua (N) cap nhat tham so");
  Serial.println("   arm                    : Kich hoat van hanh (Yeu cau pass cac buoc Critical)");
  Serial.println("   disarm                 : Khoa an toan, dung toan bo dong co");
  Serial.println("   mode op / mode bench   : Chuyen doi che do Van hanh / Kiem chuan");
  Serial.println("   status                 : Kiem tra dieu kien Gating & trang thai he thong");
  Serial.println("=======================================================");
  Serial.printf(" M1 DANG LUU FLASH : %+.2f do (%ld counts) | GIOI HAN: 0.0° -> %+.1f°\n", defaultDeg1, defaultCount1, CFG_I_AZ_MAX_SOFT_LIMIT_DEG);
  Serial.printf(" M2 DANG LUU FLASH : %+.2f do (%ld counts) | GIOI HAN: %+.1f° -> %+.1f°\n", defaultDeg2, defaultCount2, CFG_L_EL_MIN_SOFT_LIMIT_DEG, CFG_J_EL_MAX_SOFT_LIMIT_DEG);
  Serial.printf(" VI TRI ENCODER    : %s\n",
                (encoderLocation == ENCODER_ON_LOAD) ? "O TAI / TRUC TAM (0.15°/count, 32 xung/count - KHONG CHIA 3)" :
                (encoderLocation == ENCODER_ON_MOTOR) ? "O TRUC MOTOR (0.05°/count, 10.67 xung/count - CO CHIA 3)" :
                "CHUA XAC NHAN (UNKNOWN - Tam tinh 0.15°/count, hay chay Bench B2!)");
  Serial.printf(" TOC DO AUTO [G, H]: %lu Hz | TOC DO TAY: %lu Hz | GIA TOC: %lu | BUOC: %d\n",
                autoSpeedHz, manualSpeedHz, stepperAccel, stepsPerPress);
  Serial.println("=======================================================\n");
}

// -------------------------------------------------------------------------
// 8. HÀM PHÁT XUNG BƯỚC KHÔNG CHẶN QUA FASTACCELSTEPPER (CÓ RAMP GIA TỐC)
// -------------------------------------------------------------------------
bool moveMotorSteps(int axis, bool direction, int32_t steps, uint32_t speedHz = 0) {
  FastAccelStepper* s = (axis == 1) ? stepper1 : stepper2;
  if (!s) return false;

  bool isHome = (axis == 1) ? isHome1Triggered() : isHome2Triggered();
  if (direction == DIR_TOWARD_HOME && isHome) {
    Serial.printf(">> [KHOA TRUC %d] Dang cham CTHT Home! Khong quay tiep vao Home.\n", axis);
    return false;
  }

  // KIỂM TRA GIỚI HẠN MỀM AN TOÀN KHI QUAY RA XA HOME
  if (direction == DIR_AWAY_HOME) {
    if (axis == 1 && getAngleDeg1() >= CFG_I_AZ_MAX_SOFT_LIMIT_DEG) {
      Serial.printf(">> [GIOI HAN MEM TRUC 1] Phi = %+.1f° >= %+.1f° (Chong xoan cap)! Khoa chieu quay ra xa.\n",
                    getAngleDeg1(), CFG_I_AZ_MAX_SOFT_LIMIT_DEG);
      return false;
    }
    if (axis == 2) {
      if (getElevationEpsilon() >= CFG_J_EL_MAX_SOFT_LIMIT_DEG) {
        Serial.printf(">> [GIOI HAN MEM TRUC 2] Epsilon = %+.1f° >= %+.1f° (Gioi han ngua toi da %+.1f°)! Khoa chieu quay ra xa.\n",
                      getElevationEpsilon(), CFG_J_EL_MAX_SOFT_LIMIT_DEG, CFG_J_EL_MAX_SOFT_LIMIT_DEG);
        return false;
      }
      if (getElevationEpsilon() <= CFG_L_EL_MIN_SOFT_LIMIT_DEG) {
        Serial.printf(">> [GIOI HAN MEM TRUC 2] Epsilon = %+.1f° <= %+.1f° (Chong can khung Z)! Khoa ha thap.\n",
                      getElevationEpsilon(), CFG_L_EL_MIN_SOFT_LIMIT_DEG);
        return false;
      }
    }
  }

  if (speedHz == 0) speedHz = manualSpeedHz;
  s->setSpeedInHz(speedHz);
  s->setAcceleration(stepperAccel);

  int32_t delta = (direction == DIR_AWAY_HOME) ? steps : -steps;
  s->move(delta); // Non-blocking: phần cứng RMT/MCPWM tự phát xung, CPU không bị chặn!
  requestTelemetryPrint();
  return true;
}

// -------------------------------------------------------------------------
// 9. SINGLE AUTO HOMING CHO 1 TRỤC [G] (2 TỐC ĐỘ: NHANH + RÀ CHẬM)
// -------------------------------------------------------------------------
void runSingleAutoHoming(int axis) {
  FastAccelStepper* s = (axis == 1) ? stepper1 : stepper2;
  if (!s) return;

  const char* axisName = (axis == 1) ? "Truc 1 (Azimuth)" : "Truc 2 (Elevation)";
  float targetDeg = (axis == 1) ? defaultDeg1 : defaultDeg2;
  int32_t targetCount = (axis == 1) ? defaultCount1 : defaultCount2;

  Serial.println("\n=======================================================");
  Serial.printf(">> [KICH HOAT SINGLE AUTO HOMING (G)] - %s\n", axisName);
  Serial.printf("   Muc tieu ve default: %+.2f do giang pin (%ld counts)\n", targetDeg, targetCount);
  Serial.println("   Chu trinh Homing 2 toc do: [1] Chay nhanh -> [2] Lui nha switch -> [3] Ra cham -> [4] Ve Default");
  Serial.println("   (Bam [Space] hoac [X] de dung khan cap)");
  Serial.println("=======================================================");

  if (axis == 1) stateM1 = STATE_AUTO_HOMING;
  else           stateM2 = STATE_AUTO_HOMING;

  auto checkCancel = [&]() -> bool {
    if (Serial.available() > 0) {
      char c = Serial.read();
      if (c == ' ' || c == 'x' || c == 'X') {
        s->stopMove();
        stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
        Serial.println("\n>> [STOP] Da dung khan cap Single Homing!");
        requestTelemetryPrint();
        return true;
      }
    }
    return false;
  };

  auto isTriggered = [&]() -> bool {
    return (axis == 1) ? isHome1Triggered() : isHome2Triggered();
  };

  uint32_t tStart = millis();

  // BƯỚC 1: NẾU ĐANG CHẠM HOME TỪ TRƯỚC -> LÙI RA
  if (isTriggered()) {
    Serial.println(">> [BUOC 0] Dang cham switch san -> Dang lui ra xa...");
    s->setSpeedInHz(manualSpeedHz);
    s->setAcceleration(stepperAccel);
    s->move(HOME_RETRACT_STEPS);
    while (s->isRunning()) {
      if (checkCancel()) return;
      delay(2);
    }
    delay(100);
  }

  // BƯỚC 2: TIẾP CẬN NHANH (FAST APPROACH)
  Serial.println(">> [BUOC 1] Dang chay nhanh tiep can Home (Fast Approach 2800 Hz)...");
  s->setSpeedInHz(HOME_FAST_SPEED_HZ);
  s->setAcceleration(stepperAccel);
  s->runBackward();

  while (!isTriggered()) {
    if (checkCancel()) return;
    if (millis() - tStart > 35000) {
      s->stopMove();
      stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
      Serial.println("\n>> [CANH BAO AN TOAN] Timeout 35s! Da dung.");
      requestTelemetryPrint();
      return;
    }
    delay(1);
  }

  s->forceStopAndNewPosition(0);
  Serial.println(">> [BUOC 1 OK] Da cham switch lan 1! Dung ngay lap tuc.");
  delay(150);

  // BƯỚC 3: LÙI RA XA ĐỂ NHẢ SWITCH (RETRACT / BACK-OFF)
  Serial.println(">> [BUOC 2] Dang lui ra xa de switch nha hoan toan (Back-off 300 buoc)...");
  s->setSpeedInHz(manualSpeedHz);
  s->setAcceleration(stepperAccel);
  s->move(HOME_RETRACT_STEPS);
  while (s->isRunning()) {
    if (checkCancel()) return;
    delay(2);
  }
  delay(150);

  // BƯỚC 4: RÀ CHẬM TIẾP XÚC CHÍNH XÁC (SLOW CREEP 400 HZ)
  Serial.println(">> [BUOC 3] Dang ra cham tiep xuc chinh xac (Slow Creep 400 Hz, sai so <= 1 buoc)...");
  s->setSpeedInHz(HOME_CREEP_SPEED_HZ);
  s->setAcceleration(stepperAccel);
  s->runBackward();

  uint32_t tCreepStart = millis();
  while (!isTriggered()) {
    if (checkCancel()) return;
    if (millis() - tCreepStart > 10000) {
      s->stopMove();
      stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
      Serial.println("\n>> [CANH BAO AN TOAN] Timeout 10s o pha ra cham! Da dung.");
      requestTelemetryPrint();
      return;
    }
    delay(1);
  }

  s->forceStopAndNewPosition(0);
  if (axis == 1) resetEncoder1(0); else resetEncoder2(0);
  Serial.printf(">> [BUOC 3 OK] %s DA CHOT MOC HOME 0.0° CHINH XAC TUYET DOI!\n", axisName);
  requestTelemetryPrint();
  delay(250);

  // BƯỚC 5: QUAY VỀ MỐC MẶC ĐỊNH (SEEK DEFAULT)
  Serial.println(">> [BUOC 4] Dang quay ve vi tri mac dinh da luu...");
  if (axis == 1) stateM1 = STATE_AUTO_SEEK_DEFAULT;
  else           stateM2 = STATE_AUTO_SEEK_DEFAULT;

  s->setSpeedInHz(autoSpeedHz);
  s->setAcceleration(stepperAccel);
  s->runForward();

  bool reached = false;
  uint32_t p2Start = millis();

  while (!reached) {
    if (checkCancel()) return;

    int32_t curCnt = (axis == 1) ? encoderCount1 : encoderCount2;
    reached = (targetCount >= 0) ? (curCnt >= targetCount) : (curCnt <= targetCount);

    if (reached) {
      s->stopMove();
      Serial.printf(">> [%s VE DICH] Dat: %+.2f do gian pin (%ld counts)\n", axisName, (axis == 1) ? getAngleDeg1() : getAngleDeg2(), curCnt);
      break;
    }

    // Khi cách đích < 50 counts, giảm tốc mượt mà
    if (abs(targetCount - curCnt) < 50) {
      s->setSpeedInHz(autoSpeedHz / 2);
      s->applySpeedAcceleration();
    }

    if (millis() - p2Start > 35000) {
      s->stopMove();
      stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
      Serial.println("\n>> [CANH BAO AN TOAN] Timeout 35s Seek Default! Da dung.");
      requestTelemetryPrint();
      return;
    }
    delay(2);
  }

  while (s->isRunning()) delay(5);

  stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
  Serial.printf("\n>> [HOAN TAT] %s da hoan tat Homing 2 toc do va ve vi tri mac dinh!\n\n", axisName);
  requestTelemetryPrint();
}

// -------------------------------------------------------------------------
// 10. DUAL AUTO HOMING: CẢ 2 TRỤC VỀ HOME RỒI VỀ MẶC ĐỊNH [H] (2 TỐC ĐỘ ĐỒNG THỜI)
// -------------------------------------------------------------------------
void runDualAutoHoming() {
  if (!stepper1 || !stepper2) return;

  Serial.println("\n=======================================================");
  Serial.println(">> [KICH HOAT DUAL AUTO HOMING CUNG LUC CHO CA 2 TRUC (H)]");
  Serial.printf("   Truc 1 (Azimuth)  : Home -> Muc tieu: %+.2f do (%ld counts)\n", defaultDeg1, defaultCount1);
  Serial.printf("   Truc 2 (Elevation): Home -> Muc tieu: %+.2f do (%ld counts)\n", defaultDeg2, defaultCount2);
  Serial.println("   Chu trinh Homing 2 toc do DONG THOI: [1] Chay nhanh -> [2] Lui nha switch -> [3] Ra cham -> [4] Ve Default");
  Serial.println("   (Bam [Space] hoac [X] de dung khan cap)");
  Serial.println("=======================================================");

  stateM1 = STATE_AUTO_HOMING;
  stateM2 = STATE_AUTO_HOMING;

  enum AxisHomeStage { STAGE_INIT, STAGE_FAST, STAGE_RETRACT, STAGE_CREEP, STAGE_DONE };
  AxisHomeStage stage1 = STAGE_INIT;
  AxisHomeStage stage2 = STAGE_INIT;

  auto checkCancel = [&]() -> bool {
    if (Serial.available() > 0) {
      char c = Serial.read();
      if (c == ' ' || c == 'x' || c == 'X') {
        stepper1->stopMove();
        stepper2->stopMove();
        stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
        Serial.println("\n>> [STOP] Da dung khan cap Dual Homing!");
        requestTelemetryPrint();
        return true;
      }
    }
    return false;
  };

  // Khởi động giai đoạn cho từng trục
  if (isHome1Triggered()) {
    stepper1->setSpeedInHz(manualSpeedHz);
    stepper1->setAcceleration(stepperAccel);
    stepper1->move(HOME_RETRACT_STEPS);
    stage1 = STAGE_RETRACT;
    Serial.println(">> [M1] Dang cham switch san -> Dang lui ra...");
  } else {
    stepper1->setSpeedInHz(HOME_FAST_SPEED_HZ);
    stepper1->setAcceleration(stepperAccel);
    stepper1->runBackward();
    stage1 = STAGE_FAST;
  }

  if (isHome2Triggered()) {
    stepper2->setSpeedInHz(manualSpeedHz);
    stepper2->setAcceleration(stepperAccel);
    stepper2->move(HOME_RETRACT_STEPS);
    stage2 = STAGE_RETRACT;
    Serial.println(">> [M2] Dang cham switch san -> Dang lui ra...");
  } else {
    stepper2->setSpeedInHz(HOME_FAST_SPEED_HZ);
    stepper2->setAcceleration(stepperAccel);
    stepper2->runBackward();
    stage2 = STAGE_FAST;
  }

  uint32_t p1Start = millis();

  // VÒNG LẶP HOMING 2 TỐC ĐỘ ĐỒNG THỜI CHO CẢ 2 TRỤC
  while (stage1 != STAGE_DONE || stage2 != STAGE_DONE) {
    if (checkCancel()) return;

    if (millis() - p1Start > 45000) {
      stepper1->stopMove();
      stepper2->stopMove();
      stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
      Serial.println("\n>> [CANH BAO AN TOAN] Timeout 45s Dual Homing! Da dung.");
      requestTelemetryPrint();
      return;
    }

    // Xử lý trục 1
    switch (stage1) {
      case STAGE_FAST:
        if (isHome1Triggered()) {
          stepper1->forceStopAndNewPosition(0);
          Serial.println(">> [M1 FAST OK] Da cham switch 1 lan dau! Dang lui ra...");
          stepper1->setSpeedInHz(manualSpeedHz);
          stepper1->setAcceleration(stepperAccel);
          stepper1->move(HOME_RETRACT_STEPS);
          stage1 = STAGE_RETRACT;
        }
        break;

      case STAGE_RETRACT:
        if (!stepper1->isRunning() && !isHome1Triggered()) {
          Serial.println(">> [M1 CREEP] Dang ra cham switch 1 voi toc do 400 Hz...");
          stepper1->setSpeedInHz(HOME_CREEP_SPEED_HZ);
          stepper1->setAcceleration(stepperAccel);
          stepper1->runBackward();
          stage1 = STAGE_CREEP;
        }
        break;

      case STAGE_CREEP:
        if (isHome1Triggered()) {
          stepper1->forceStopAndNewPosition(0);
          resetEncoder1(0);
          stage1 = STAGE_DONE;
          Serial.println(">> [M1 DUAL 2-STAGE OK] Truc 1 da chot Home 0.0° chinh xac!");
          requestTelemetryPrint();
        }
        break;

      case STAGE_DONE:
      default:
        break;
    }

    // Xử lý trục 2
    switch (stage2) {
      case STAGE_FAST:
        if (isHome2Triggered()) {
          stepper2->forceStopAndNewPosition(0);
          Serial.println(">> [M2 FAST OK] Da cham switch 2 lan dau! Dang lui ra...");
          stepper2->setSpeedInHz(manualSpeedHz);
          stepper2->setAcceleration(stepperAccel);
          stepper2->move(HOME_RETRACT_STEPS);
          stage2 = STAGE_RETRACT;
        }
        break;

      case STAGE_RETRACT:
        if (!stepper2->isRunning() && !isHome2Triggered()) {
          Serial.println(">> [M2 CREEP] Dang ra cham switch 2 voi toc do 400 Hz...");
          stepper2->setSpeedInHz(HOME_CREEP_SPEED_HZ);
          stepper2->setAcceleration(stepperAccel);
          stepper2->runBackward();
          stage2 = STAGE_CREEP;
        }
        break;

      case STAGE_CREEP:
        if (isHome2Triggered()) {
          stepper2->forceStopAndNewPosition(0);
          resetEncoder2(0);
          stage2 = STAGE_DONE;
          Serial.println(">> [M2 DUAL 2-STAGE OK] Truc 2 da chot Home 0.0° chinh xac!");
          requestTelemetryPrint();
        }
        break;

      case STAGE_DONE:
      default:
        break;
    }

    delay(1);
  }

  Serial.println("\n>> [PHA 1 HOAN TAT 100%] Ca 2 truc da chot diem Home 0.0° voi do chinh xac tuyet doi!");
  Serial.println(">> Nghi 0.25s triet tieu quan tinh truoc khi sang Pha 2...");
  delay(250);

  // PHA 2: CHẠY ĐỒNG THỜI VỀ VỊ TRÍ MẶC ĐỊNH M1 VÀ M2
  Serial.println(">> Pha 2: Ca 2 truc dang DONG THOI quay ve vi tri mac dinh (FastAccelStepper)...");
  stateM1 = STATE_AUTO_SEEK_DEFAULT;
  stateM2 = STATE_AUTO_SEEK_DEFAULT;

  stepper1->setSpeedInHz(autoSpeedHz);
  stepper1->setAcceleration(stepperAccel);
  stepper1->runForward();

  stepper2->setSpeedInHz(autoSpeedHz);
  stepper2->setAcceleration(stepperAccel);
  stepper2->runForward();

  bool m1Reached = false;
  bool m2Reached = false;
  uint32_t p2Start = millis();

  while (!m1Reached || !m2Reached) {
    if (checkCancel()) return;

    if (!m1Reached) {
      bool reached1 = (defaultCount1 >= 0) ? (encoderCount1 >= defaultCount1) : (encoderCount1 <= defaultCount1);
      if (reached1) {
        stepper1->stopMove();
        m1Reached = true;
        Serial.printf(">> [M1 VE DICH] Truc 1 dat: %+.2f do (%ld counts)\n", getAngleDeg1(), encoderCount1);
        requestTelemetryPrint();
      } else if (abs(defaultCount1 - encoderCount1) < 50) {
        stepper1->setSpeedInHz(autoSpeedHz / 2);
        stepper1->applySpeedAcceleration();
      }
    }

    if (!m2Reached) {
      bool reached2 = (defaultCount2 >= 0) ? (encoderCount2 >= defaultCount2) : (encoderCount2 <= defaultCount2);
      if (reached2) {
        stepper2->stopMove();
        m2Reached = true;
        Serial.printf(">> [M2 VE DICH] Truc 2 dat: %+.2f do (%ld counts)\n", getAngleDeg2(), encoderCount2);
        requestTelemetryPrint();
      } else if (abs(defaultCount2 - encoderCount2) < 50) {
        stepper2->setSpeedInHz(autoSpeedHz / 2);
        stepper2->applySpeedAcceleration();
      }
    }

    if (millis() - p2Start > 35000) {
      stepper1->stopMove();
      stepper2->stopMove();
      stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
      Serial.println("\n>> [CANH BAO AN TOAN] Timeout 35s Seek Default! Da dung.");
      requestTelemetryPrint();
      return;
    }
    delay(2);
  }

  while (stepper1->isRunning() || stepper2->isRunning()) delay(5);

  stateM1 = STATE_IDLE;
  stateM2 = STATE_IDLE;
  Serial.println("\n=======================================================");
  Serial.println(">> [DUAL AUTO HOAN TAT 100%] CA 2 TRUC DA VE DUNG DICH!");
  Serial.printf("   Truc 1 (Azimuth)  : %+.2f do giang pin (%ld counts)\n", getAngleDeg1(), encoderCount1);
  Serial.printf("   Truc 2 (Elevation): %+.2f do giang pin (%ld counts)\n", getAngleDeg2(), encoderCount2);
  Serial.println("=======================================================");
  requestTelemetryPrint();
}

// -------------------------------------------------------------------------
// 10. SETUP
// -------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  
  delay(300);
  Serial.println("\n\n=======================================================");
  Serial.println(">> BO MACH ESP32-S3 DUAL SOLAR TRACKER DA KHOI DONG!");
  Serial.println("=======================================================");

  // 1. Khởi tạo FastAccelStepper Engine phần cứng (DÙNG 100% RMT, TUYỆT ĐỐI KHÔNG DÙNG PCNT) cho Driver DM556
  engine.init();
  stepper1 = engine.stepperConnectToPin(M1_PUL_PIN, DRIVER_RMT);
  if (stepper1) {
    stepper1->setDirectionPin(M1_DIR_PIN);
    stepper1->setSpeedInHz(manualSpeedHz);
    stepper1->setAcceleration(stepperAccel);
    stepper1->setAutoEnable(false);
    Serial.println(">> [STEPPER 1 OK] Da khoi tao FastAccelStepper M1 (Azimuth - 100% RMT Hardware)!");
  } else {
    Serial.println(">> [LOI] Khong the khoi tao Stepper 1 qua FastAccelStepper!");
  }

  stepper2 = engine.stepperConnectToPin(M2_PUL_PIN, DRIVER_RMT);
  if (stepper2) {
    stepper2->setDirectionPin(M2_DIR_PIN);
    stepper2->setSpeedInHz(manualSpeedHz);
    stepper2->setAcceleration(stepperAccel);
    stepper2->setAutoEnable(false);
    Serial.println(">> [STEPPER 2 OK] Da khoi tao FastAccelStepper M2 (Elevation - 100% RMT Hardware)!");
  } else {
    Serial.println(">> [LOI] Khong the khoi tao Stepper 2 qua FastAccelStepper!");
  }

  // 2. Cấu hình Công tắc hành trình Home
  pinMode(M1_HOME_SW_PIN, INPUT_PULLUP);
  pinMode(M2_HOME_SW_PIN, INPUT_PULLUP);

  // 3. Cấu hình chân Encoder và khởi tạo bộ đếm phần cứng PCNT 4X với Glitch Filter
  pinMode(M1_ENC_A_PIN, INPUT_PULLUP);
  pinMode(M1_ENC_B_PIN, INPUT_PULLUP);
  pinMode(M2_ENC_A_PIN, INPUT_PULLUP);
  pinMode(M2_ENC_B_PIN, INPUT_PULLUP);

  initPcntEncoder(PCNT_UNIT_0, M1_ENC_A_PIN, M1_ENC_B_PIN);
  initPcntEncoder(PCNT_UNIT_1, M2_ENC_A_PIN, M2_ENC_B_PIN);

  // Đếm cạnh xung riêng biệt từng chân để chẩn đoán đứt dây pha A hoặc pha B
  attachInterrupt(digitalPinToInterrupt(M1_ENC_A_PIN), isrEnc1A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(M1_ENC_B_PIN), isrEnc1B, CHANGE);
  attachInterrupt(digitalPinToInterrupt(M2_ENC_A_PIN), isrEnc2A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(M2_ENC_B_PIN), isrEnc2B, CHANGE);

  Serial.println(">> [PCNT HARDWARE OK] Da khoi tao PCNT Unit 0 & Unit 1 (Hardware 4X + Glitch Filter 1.0us)!");
  Serial.println("   -> Da gan ngat dem canh rieng biet rawEdges cho tung chan Pha A va Pha B!\n");

  // 4. Khởi tạo Flash NVS (Preferences) & Nạp CalibrationStore
  prefs.begin("solar_pos", false);

  // Khởi tạo Bảng tham số trung tâm (ParamRegistry) & Nạp dữ liệu NVS Flash (CalibrationStore)
  CalibrationStore.begin();

  // Khởi tạo Bench Wizard (16 bước B0-B15 & Operation Gating)
  BenchWizard.begin();

  // Đồng bộ vị trí Encoder & tốc độ từ ParamRegistry
  encoderLocation = (EncoderLocation)ParamRegistry.getInt("ENCODER_ON_LOAD", (int)ENCODER_LOC_UNKNOWN);
  manualSpeedHz   = (uint32_t)ParamRegistry.get("MANUAL_SPEED_AZ", 2000.0f);
  stepperAccel    = (uint32_t)ParamRegistry.get("U_MAX_ACCEL_AZ", 5000.0f);
  invertEncoderDir1 = prefs.getBool("inv_enc1", (ParamRegistry.getInt("ENC_INVERT_AZ", 0) == 1));
  invertEncoderDir2 = prefs.getBool("inv_enc2", (ParamRegistry.getInt("ENC_INVERT_EL", 0) == 1));
  if (!prefs.isKey("def_cnt1")) prefs.putInt("def_cnt1", INIT_DEFAULT_COUNTS_1);
  if (!prefs.isKey("def_cnt2")) prefs.putInt("def_cnt2", INIT_DEFAULT_COUNTS_2);

  defaultCount1 = prefs.getInt("def_cnt1", INIT_DEFAULT_COUNTS_1);
  defaultDeg1   = (float)defaultCount1 * getDegPerCount();
  prefs.putFloat("def_deg1", defaultDeg1);

  defaultCount2 = prefs.getInt("def_cnt2", INIT_DEFAULT_COUNTS_2);
  defaultDeg2   = (float)defaultCount2 * getDegPerCount();
  prefs.putFloat("def_deg2", defaultDeg2);

  if (isHome1Triggered()) resetEncoder1(0);
  if (isHome2Triggered()) resetEncoder2(0);

  // 5. Cấu hình 4 mắt cảm biến quang TEMT6000
  pinMode(PIN_TEMT_TOP, INPUT);
  pinMode(PIN_TEMT_BOT, INPUT);
  pinMode(PIN_TEMT_LFT, INPUT);
  pinMode(PIN_TEMT_RGT, INPUT);
  analogReadResolution(12);

  // 6. Cấu hình I2C & RTC DS3231 (CÓ TIMEOUT 25ms CHỐNG TREO)
  Serial.println(">> Dang khoi tao bus I2C (SDA: GPIO 8, SCL: GPIO 9)...");
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, 100000); // Chuẩn 100 kHz
  Wire.setTimeOut(25); // Timeout 25ms: Neu day long hoac cam nguoc thi bo qua, khong bi treo!
  pinMode(DS3231_SQW_PIN, INPUT_PULLUP);

  // 7. Quét thiết bị I2C và in giờ RTC ban đầu
  scanI2CBus();
  printRTCStatus();

  // 8. Khởi tạo WiFi & Firebase Realtime Database
  Serial.printf(">> Dang ket noi WiFi toi SSID: %s ...\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long startWifi = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startWifi < 2500)) {
    delay(150);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n>> [WIFI OK] Da ket noi! IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n>> [WIFI WAIT] Dang tiep tuc ket noi ngam trong background...");
  }

  fbConfig.api_key = API_KEY;
  fbConfig.database_url = DATABASE_URL;
  fbConfig.signer.test_mode = true;
  fbConfig.timeout.socketConnection = 1500;
  fbConfig.timeout.serverResponse = 1500;
  Firebase.begin(&fbConfig, &auth);
  Firebase.reconnectWiFi(true);
  Serial.println(">> [FIREBASE OK] Da san sang day Telemetry len Web Dashboard!\n");

  // 8. Khởi tạo Mutex cho I2C & Khởi tạo Background Task trên Core 0 cho Telemetry & Firebase
  i2cMutex = xSemaphoreCreateMutex();
  xTaskCreatePinnedToCore(
    telemetryTask,
    "TelemetryTask",
    10240,            // 10 KB stack cho Firebase TLS
    NULL,
    0,                // Priority 0 (tskIDLE_PRIORITY) - Time-slice cong bang voi IDLE0, chong triet de Task Watchdog!
    &telemetryTaskHandle,
    0                 // Core 0 (PRO_CPU)
  );
  Serial.println(">> [FREE-RTOS CORE 0] TelemetryTask da khoi chay doc lap tren Core 0!");
  Serial.println("   -> Core 1 ranh tay 100% cho dieu khien dong co & bam quang!\n");

  // 9. In Menu
  printMenu();
  requestTelemetryPrint();
  Serial.print("\n[CLI]> ");
}

// -------------------------------------------------------------------------
// 11. XỬ LÝ LỆNH CLI CHUỖI (PARAM REGISTRY & CALIBRATION STORE)
// -------------------------------------------------------------------------
void handleCliCommand(const String& cmdStr) {
  if (cmdStr.equalsIgnoreCase("stop")) {
    stateM1 = STATE_IDLE;
    stateM2 = STATE_IDLE;
    autoOpticalTracking = false;
    if (stepper1) stepper1->stopMove();
    if (stepper2) stepper2->stopMove();
    BenchWizard.abort("Nguoi dung nhan E-Stop (stop)");
    Serial.println("\n>> [STOP] DA DUNG KHAN CAP TOAN BO HE THONG (FastAccelStepper Decel)!");
    requestTelemetryPrint();
  } else if (cmdStr.equalsIgnoreCase("params")) {
    ParamRegistry.printTable();
  } else if (cmdStr.equalsIgnoreCase("bench")) {
    BenchWizard.printStatus();
  } else if (cmdStr.equalsIgnoreCase("bench all")) {
    BenchWizard.startAll();
  } else if (cmdStr.startsWith("bench ") || cmdStr.startsWith("BENCH ")) {
    String arg = cmdStr.substring(6);
    arg.trim();
    if (arg.equalsIgnoreCase("abort")) {
      BenchWizard.abort();
    } else {
      int stepId = arg.toInt();
      BenchWizard.startStep(stepId);
    }
  } else if (cmdStr.equalsIgnoreCase("y") || cmdStr.equalsIgnoreCase("yes")) {
    BenchWizard.confirm(true);
  } else if (cmdStr.equalsIgnoreCase("n") || cmdStr.equalsIgnoreCase("no")) {
    BenchWizard.confirm(false);
  } else if (cmdStr.equalsIgnoreCase("arm")) {
    BenchWizard.arm();
  } else if (cmdStr.equalsIgnoreCase("disarm")) {
    BenchWizard.disarm();
  } else if (cmdStr.equalsIgnoreCase("mode op") || cmdStr.equalsIgnoreCase("mode operation")) {
    BenchWizard.setSystemMode(MODE_OPERATION);
  } else if (cmdStr.equalsIgnoreCase("mode bench")) {
    BenchWizard.setSystemMode(MODE_BENCH);
  } else if (cmdStr.equalsIgnoreCase("status")) {
    BenchWizard.printStatus();
  } else if (cmdStr.startsWith("set ") || cmdStr.startsWith("SET ")) {
    int firstSpace = cmdStr.indexOf(' ');
    int secondSpace = cmdStr.indexOf(' ', firstSpace + 1);
    if (secondSpace < 0) {
      Serial.println(">> Cu phap sai! Hay dung: set <TEN_THAM_SO> <GIATRI>");
    } else {
      String pName = cmdStr.substring(firstSpace + 1, secondSpace);
      pName.trim();
      String pValStr = cmdStr.substring(secondSpace + 1);
      pValStr.trim();
      float val = pValStr.toFloat();
      ParamEntry* pe = ParamRegistry.getEntry(pName.c_str());
      if (!pe) {
        Serial.printf(">> [PARAM] Loi: Khong tim thay tham so '%s'!\n", pName.c_str());
      } else {
        float oldVal = pe->val;
        if (ParamRegistry.set(pName.c_str(), val, PARAM_SRC_MANUAL, "MANUAL")) {
          CalibrationStore.save();
          Serial.printf(">> [PARAM OK] %s: %.4f -> %.4f (%s) [Da luu NVS Flash]\n",
                        pName.c_str(), oldVal, val, pe->unit);
          if (pName.equalsIgnoreCase("MANUAL_SPEED_AZ") || pName.equalsIgnoreCase("MANUAL_SPEED_EL")) {
            manualSpeedHz = (uint32_t)val;
          } else if (pName.equalsIgnoreCase("U_MAX_ACCEL_AZ") || pName.equalsIgnoreCase("U_MAX_ACCEL_EL")) {
            stepperAccel = (uint32_t)val;
          } else if (pName.equalsIgnoreCase("ENCODER_ON_LOAD")) {
            encoderLocation = (EncoderLocation)ParamRegistry.getInt("ENCODER_ON_LOAD", (int)ENCODER_LOC_UNKNOWN);
          }
        }
      }
    }
  } else if (cmdStr.startsWith("rollback ") || cmdStr.startsWith("ROLLBACK ")) {
    int spaceIdx = cmdStr.indexOf(' ');
    String pName = cmdStr.substring(spaceIdx + 1);
    pName.trim();
    if (ParamRegistry.rollback(pName.c_str())) {
      CalibrationStore.save();
      Serial.printf(">> [PARAM OK] Da rollback '%s' ve %.4f va luu NVS!\n",
                    pName.c_str(), ParamRegistry.get(pName.c_str()));
      if (pName.equalsIgnoreCase("ENCODER_ON_LOAD")) {
        encoderLocation = (EncoderLocation)ParamRegistry.getInt("ENCODER_ON_LOAD", (int)ENCODER_LOC_UNKNOWN);
      }
    }
  } else if (cmdStr.equalsIgnoreCase("calib save")) {
    CalibrationStore.save();
  } else if (cmdStr.equalsIgnoreCase("calib load")) {
    CalibrationStore.load();
    encoderLocation = (EncoderLocation)ParamRegistry.getInt("ENCODER_ON_LOAD", (int)ENCODER_LOC_UNKNOWN);
    manualSpeedHz = (uint32_t)ParamRegistry.get("MANUAL_SPEED_AZ", 2000.0f);
    stepperAccel = (uint32_t)ParamRegistry.get("U_MAX_ACCEL_AZ", 5000.0f);
  } else if (cmdStr.equalsIgnoreCase("calib reset")) {
    CalibrationStore.resetToDefaults();
    encoderLocation = (EncoderLocation)ParamRegistry.getInt("ENCODER_ON_LOAD", (int)ENCODER_LOC_UNKNOWN);
    manualSpeedHz = (uint32_t)ParamRegistry.get("MANUAL_SPEED_AZ", 2000.0f);
    stepperAccel = (uint32_t)ParamRegistry.get("U_MAX_ACCEL_AZ", 5000.0f);
  } else if (cmdStr.equalsIgnoreCase("calib export") || cmdStr.equalsIgnoreCase("export")) {
    CalibrationStore.printJson();
  } else if (cmdStr.equalsIgnoreCase("raw") || cmdStr.equalsIgnoreCase("enc")) {
    rawEncStream = !rawEncStream;
    Serial.printf("\n>> [RAW ENCODER STREAM: %s] %s\n",
                  rawEncStream ? "ON" : "OFF",
                  rawEncStream ? "Dang in muc logic thô & so canh rieng Pha A/B moi 200ms... (Go 'raw' hoac bam [K] de tat)" : "Da tat stream.");
  } else if (cmdStr.startsWith("time ") || cmdStr.startsWith("rtc set ") || cmdStr.startsWith("rtc ")) {
    int hh = 0, mm = 0, ss = 0, d = 1, m = 11, y = 2026;
    String arg = cmdStr;
    if (arg.startsWith("time ")) arg = arg.substring(5);
    else if (arg.startsWith("rtc set ")) arg = arg.substring(8);
    else if (arg.startsWith("rtc ")) arg = arg.substring(4);
    arg.trim();
    int parsed = sscanf(arg.c_str(), "%d:%d:%d %d/%d/%d", &hh, &mm, &ss, &d, &m, &y);
    if (parsed >= 3) {
      if (writeDS3231(y, m, d, hh, mm, ss)) {
        Serial.printf("\n>> [RTC DS3231 OK] Da cai dat gio thanh cong: %02d:%02d:%02d ngay %02d/%02d/%04d!\n",
                      hh, mm, ss, d, m, y);
      } else {
        Serial.println("\n>> [LOI] Khong the ghi gio vao DS3231 qua I2C!");
      }
    } else {
      Serial.println("\n>> Cu phap: 'time HH:MM:SS DD/MM/YYYY' (Vi du: time 23:05:00 01/11/2026)");
    }
  } else if (cmdStr.equalsIgnoreCase("help") || cmdStr.equalsIgnoreCase("menu") || cmdStr.equalsIgnoreCase("?")) {
    printMenu();
  } else {
    Serial.printf(">> Lenh khong hop le: '%s'. Go 'params' de xem tham so hoac 'r' de xem menu.\n", cmdStr.c_str());
  }
}

// -------------------------------------------------------------------------
// 12. LOOP CHÍNH
// -------------------------------------------------------------------------
void loop() {
  // Cập nhật trạng thái Bench Wizard theo thời gian thực (Non-blocking)
  BenchWizard.update();

  // Cập nhật đếm xung phần cứng PCNT thời gian thực
  getEncoderCount1();
  getEncoderCount2();

  // A. XỬ LÝ LỆNH TỪ SERIAL MONITOR (NON-BLOCKING + DỪNG KHẨN CẤP <50ms)
  static String serialLineBuffer = "";
  static unsigned long lastSerialCharMs = 0;
  char cmd = 0;
  bool hasCmd = false;

  while (Serial.available() > 0) {
    char c = (char)Serial.read();

    // DỪNG KHẨN CẤP TỨC THÌ (<1ms):
    // - Phím ESC (ASCII 27) luôn dừng ngay lập tức ở mọi tình huống
    // - Phím Space hoặc X/x khi chưa bắt đầu gõ lệnh (buffer rỗng)
    if (c == 27 || (serialLineBuffer.length() == 0 && (c == ' ' || c == 'x' || c == 'X'))) {
      stateM1 = STATE_IDLE;
      stateM2 = STATE_IDLE;
      autoOpticalTracking = false;
      if (stepper1) stepper1->stopMove();
      if (stepper2) stepper2->stopMove();
      BenchWizard.abort("Nguoi dung nhan E-Stop (Space/X/ESC)");
      Serial.println("\n>> [STOP] DA DUNG KHAN CAP TOAN BO HE THONG (FastAccelStepper Decel)!");
      Serial.println(">> (Goi y: Go 'menu' hoac '?' de xem huong dan, 'params' de xem thong so, 'set ...' de cai dat)");
      Serial.print("\n[CLI]> ");
      requestTelemetryPrint();
      serialLineBuffer = "";
      return;
    }

    if (c == '\r' || c == '\n') {
      if (serialLineBuffer.length() > 0) {
        String line = serialLineBuffer;
        serialLineBuffer = "";
        line.trim();
        Serial.println(); // Xuong dong tren man hinh Terminal
        if (line.length() == 1) {
          cmd = line.charAt(0);
          hasCmd = true;
          break;
        } else if (line.length() > 1) {
          handleCliCommand(line);
          Serial.print("\n[CLI]> ");
        }
      } else {
        Serial.print("\n[CLI]> ");
      }
    } else if (c == '\b' || (uint8_t)c == 127) {
      if (serialLineBuffer.length() > 0) {
        serialLineBuffer.remove(serialLineBuffer.length() - 1);
        Serial.print("\b \b"); // Xoa ky tu tren man hinh Terminal
      }
    } else if (c >= 32 && c <= 126) {
      serialLineBuffer += c;
      Serial.print(c); // ECHO truc tiep de nguoi dung thay ky tu minh dang go!
    }
  }

  if (hasCmd) {

    if (cmd == ' ' || cmd == 'x' || cmd == 'X') {
      stateM1 = STATE_IDLE;
      stateM2 = STATE_IDLE;
      autoOpticalTracking = false;
      if (stepper1) stepper1->stopMove();
      if (stepper2) stepper2->stopMove();
      Serial.println("\n>> [STOP] DA DUNG KHAN CAP TOAN BO HE THONG (FastAccelStepper Decel)!");
      requestTelemetryPrint();
      return;
    }

    if (cmd == '1') {
      activeAxis = 1;
      Serial.println("\n>> DANG CHON DIEU KHIEN: TRUC 1 (AZIMUTH - GOC QUAY)");
      requestTelemetryPrint();
      return;
    }
    if (cmd == '2') {
      activeAxis = 2;
      Serial.println("\n>> DANG CHON DIEU KHIEN: TRUC 2 (ELEVATION - DO NGUA)");
      requestTelemetryPrint();
      return;
    }

    switch (cmd) {
      case 'a': case 'A':
        stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
        moveMotorSteps(activeAxis, DIR_TOWARD_HOME, stepsPerPress);
        break;

      case 'd': case 'D':
        stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
        moveMotorSteps(activeAxis, DIR_AWAY_HOME, stepsPerPress);
        break;

      case 'q': case 'Q':
        if (activeAxis == 1) {
          if (isHome1Triggered()) {
            Serial.println(">> [TRUC 1] Dang cham Home, khong the chay tiep ve Home!");
          } else {
            stateM1 = STATE_MANUAL_TOWARD_HOME;
            stepper1->setSpeedInHz(manualSpeedHz);
            stepper1->setAcceleration(stepperAccel);
            stepper1->runBackward(); // Non-blocking: tăng tốc êm ái
            Serial.println(">> [TRUC 1] Chay lien tuc ve Home (FastAccelStepper)...");
          }
        } else {
          if (isHome2Triggered()) {
            Serial.println(">> [TRUC 2] Dang cham Home, khong the chay tiep ve Home!");
          } else {
            stateM2 = STATE_MANUAL_TOWARD_HOME;
            stepper2->setSpeedInHz(manualSpeedHz);
            stepper2->setAcceleration(stepperAccel);
            stepper2->runBackward(); // Non-blocking: tăng tốc êm ái
            Serial.println(">> [TRUC 2] Chay lien tuc ve Home (FastAccelStepper)...");
          }
        }
        break;

      case 'e': case 'E':
        if (activeAxis == 1) {
          if (getAngleDeg1() >= CFG_I_AZ_MAX_SOFT_LIMIT_DEG) {
            Serial.printf(">> [TRUC 1] Goc phi = %+.1f° da cham gioi han mem %+.1f° (Chong xoan cap)! Khong chay.\n",
                          getAngleDeg1(), CFG_I_AZ_MAX_SOFT_LIMIT_DEG);
          } else {
            stateM1 = STATE_MANUAL_AWAY_HOME;
            stepper1->setSpeedInHz(manualSpeedHz);
            stepper1->setAcceleration(stepperAccel);
            stepper1->runForward(); // Non-blocking: tăng tốc êm ái
            Serial.println(">> [TRUC 1] Chay lien tuc ra xa Home (FastAccelStepper)...");
          }
        } else {
          if (getElevationEpsilon() >= CFG_J_EL_MAX_SOFT_LIMIT_DEG) {
            Serial.printf(">> [TRUC 2] Goc ngua epsilon = %+.1f° da cham gioi han ngua toi da %+.1f°! Khong ngua tiep.\n",
                          getElevationEpsilon(), CFG_J_EL_MAX_SOFT_LIMIT_DEG);
          } else if (getElevationEpsilon() <= CFG_L_EL_MIN_SOFT_LIMIT_DEG) {
            Serial.printf(">> [TRUC 2] Goc ngua epsilon = %+.1f° da cham gioi han ha thap an toan %+.1f° (Chong can khung Z)! Khong ha.\n",
                          getElevationEpsilon(), CFG_L_EL_MIN_SOFT_LIMIT_DEG);
          } else {
            stateM2 = STATE_MANUAL_AWAY_HOME;
            stepper2->setSpeedInHz(manualSpeedHz);
            stepper2->setAcceleration(stepperAccel);
            stepper2->runForward(); // Non-blocking: tăng tốc êm ái
            Serial.println(">> [TRUC 2] Chay lien tuc ra xa Home (FastAccelStepper)...");
          }
        }
        break;

      case 'm': case 'M':
        if (activeAxis == 1) {
          defaultCount1 = encoderCount1; defaultDeg1 = getAngleDeg1();
          prefs.putInt("def_cnt1", defaultCount1); prefs.putFloat("def_deg1", defaultDeg1);
          Serial.printf("\n>> [NVS] Da luu goc mac dinh M1: %+.2f do gian pin (%ld counts)\n", defaultDeg1, defaultCount1);
        } else {
          defaultCount2 = encoderCount2; defaultDeg2 = getAngleDeg2();
          prefs.putInt("def_cnt2", defaultCount2); prefs.putFloat("def_deg2", defaultDeg2);
          Serial.printf("\n>> [NVS] Da luu goc mac dinh M2: %+.2f do gian pin (%ld counts)\n", defaultDeg2, defaultCount2);
        }
        break;

      case '0':
        if (activeAxis == 1) { resetEncoder1(0); Serial.println(">> Set M1 = 0.0°"); }
        else                 { resetEncoder2(0); Serial.println(">> Set M2 = 0.0°"); }
        break;

      case 'i': case 'I':
        if (activeAxis == 1) {
          invertEncoderDir1 = !invertEncoderDir1;
          encoderCount1 = -encoderCount1;
          swEncoderCount1 = -swEncoderCount1;
          prefs.putBool("inv_enc1", invertEncoderDir1);
          ParamRegistry.set("ENC_INVERT_AZ", invertEncoderDir1 ? 1.0f : 0.0f, PARAM_SRC_MANUAL, "MANUAL");
          CalibrationStore.save();
          Serial.printf(">> [ENC 1] Dao chieu dem: %s | Goc hien tai: %+.2f do (%ld counts)\n",
                        invertEncoderDir1 ? "NGHICH (-)" : "THUAN (+)", getAngleDeg1(), encoderCount1);
        } else {
          invertEncoderDir2 = !invertEncoderDir2;
          encoderCount2 = -encoderCount2;
          swEncoderCount2 = -swEncoderCount2;
          prefs.putBool("inv_enc2", invertEncoderDir2);
          ParamRegistry.set("ENC_INVERT_EL", invertEncoderDir2 ? 1.0f : 0.0f, PARAM_SRC_MANUAL, "MANUAL");
          CalibrationStore.save();
          Serial.printf(">> [ENC 2] Dao chieu dem: %s | Goc hien tai: %+.2f do (%ld counts)\n",
                        invertEncoderDir2 ? "NGHICH (-)" : "THUAN (+)", getAngleDeg2(), encoderCount2);
        }
        break;

      // PHÍM G: SINGLE AUTO HOMING CHO TRỤC ĐANG CHỌN
      case 'g': case 'G':
        autoOpticalTracking = false;
        runSingleAutoHoming(activeAxis);
        break;

      // PHÍM H: DUAL AUTO HOMING & VỀ MỐC MẶC ĐỊNH
      case 'h': case 'H':
        autoOpticalTracking = false;
        runDualAutoHoming();
        break;

      // PHÍM V: BẬT / TẮT CHẾ ĐỘ LIVE ENCODER MONITOR
      case 'v': case 'V':
        liveEncoderMonitor = !liveEncoderMonitor;
        if (liveEncoderMonitor) {
          Serial.println("\n=======================================================");
          Serial.println(">> [LIVE ENCODER MONITOR: ON] DA BAT THEO DOI ENCODER LIVE!");
          Serial.println("   Xoay truc encoder bang tay -> Moi canh ngat se in ngay lap tuc!");
          Serial.println("   (Bam [V] lan nua de tat).");
          Serial.println("=======================================================\n");
        } else {
          Serial.println("\n>> [LIVE ENCODER MONITOR: OFF] Da tat theo doi live.\n");
        }
        break;

      // CHỈNH TỐC ĐỘ AUTO HOMING [ ] (Hz)
      case ']': case '}':
        autoSpeedHz += 200;
        Serial.printf(">> TANG TOC DO AUTO [G, H]: %lu Hz\n", autoSpeedHz);
        break;

      case '[': case '{':
        if (autoSpeedHz > 400) autoSpeedHz -= 200;
        Serial.printf(">> GIAM TOC DO AUTO [G, H]: %lu Hz\n", autoSpeedHz);
        break;

      // CHỈNH BƯỚC VÀ TỐC ĐỘ TAY
      case '+': case '=':
        stepsPerPress += 100;
        Serial.printf(">> TANG SO BUOC TAY: %d buoc/lan\n", stepsPerPress);
        break;

      case '-': case '_':
        if (stepsPerPress > 100) stepsPerPress -= 100;
        Serial.printf(">> GIAM SO BUOC TAY: %d buoc/lan\n", stepsPerPress);
        break;

      case '>': case '.':
        manualSpeedHz += 200;
        if (stepper1) stepper1->setSpeedInHz(manualSpeedHz);
        if (stepper2) stepper2->setSpeedInHz(manualSpeedHz);
        Serial.printf(">> TANG TOC DO TAY: %lu Hz\n", manualSpeedHz);
        break;

      case '<': case ',':
        if (manualSpeedHz > 400) manualSpeedHz -= 200;
        if (stepper1) stepper1->setSpeedInHz(manualSpeedHz);
        if (stepper2) stepper2->setSpeedInHz(manualSpeedHz);
        Serial.printf(">> GIAM TOC DO TAY: %lu Hz\n", manualSpeedHz);
        break;

      // PHÍM O: BẬT / TẮT CHẾ ĐỘ BÁM QUANG (OPTICAL TRACKING)
      case 'o': case 'O':
        autoOpticalTracking = !autoOpticalTracking;
        stateM1 = STATE_IDLE; stateM2 = STATE_IDLE;
        if (autoOpticalTracking) {
          Serial.println("\n=======================================================");
          Serial.println(">> [OPTICAL MODE: ON] DA BAT CHE DO TU DONG BAM ANH SANG!");
          Serial.println("   ESP32 se lien tuc doc 4 mat TEMT6000 va quay gian pin");
          Serial.println("   huong ve phia nguon sang manh nhat (Bam [O] de tat).");
          Serial.println("=======================================================\n");
        } else {
          Serial.println("\n>> [OPTICAL MODE: OFF] Da tat che do bam anh sang -> Ve Idle.");
        }
        break;

      // PHÍM L: ĐỌC 4 CẢM BIẾN QUANG TEMT6000 LIVE
      case 'l': case 'L':
        printOpticalSensors();
        break;

      // PHÍM C: ĐỌC ĐỒNG HỒ RTC DS3231 & QUÉT I2C
      case 'c': case 'C':
        scanI2CBus();
        printRTCStatus();
        break;

      // PHÍM T: KIỂM TRA MỨC ĐIỆN ÁP LOGIC TẤT CẢ CÁC CHÂN & ĐẾM NGẮT
      case 't': case 'T':
        Serial.println("\n=======================================================");
        Serial.println("  [DIAGNOSTIC] KIEM TRA MUC DIEN AP LIVE TREN ESP32-S3");
        Serial.println("=======================================================");
        Serial.printf(" CTHT 1 (GPIO %2d): %s (Doc: %d)\n", M1_HOME_SW_PIN, isHome1Triggered() ? "CHAM (LOW)" : "HO (HIGH)", digitalRead(M1_HOME_SW_PIN));
        Serial.printf(" CTHT 2 (GPIO %2d): %s (Doc: %d)\n", M2_HOME_SW_PIN, isHome2Triggered() ? "CHAM (LOW)" : "HO (HIGH)", digitalRead(M2_HOME_SW_PIN));
        Serial.printf(" ENC 1 (PCNT Unit 0 - G%2d, G%2d): A=%d (edges: %6lu), B=%d (edges: %6lu) | Cnt: %ld (%+.2f do giang pin)\n",
                      M1_ENC_A_PIN, M1_ENC_B_PIN, digitalRead(M1_ENC_A_PIN), rawEdges1A, digitalRead(M1_ENC_B_PIN), rawEdges1B, getEncoderCount1(), getAngleDeg1());
        Serial.printf(" ENC 2 (PCNT Unit 1 - G%2d, G%2d): A=%d (edges: %6lu), B=%d (edges: %6lu) | Cnt: %ld (%+.2f do giang pin)\n",
                      M2_ENC_A_PIN, M2_ENC_B_PIN, digitalRead(M2_ENC_A_PIN), rawEdges2A, digitalRead(M2_ENC_B_PIN), rawEdges2B, getEncoderCount2(), getAngleDeg2());
        Serial.printf(" VI TRI ENCODER    : %s (He so: %.4f do/count | %.1f xung/count)\n",
                      (encoderLocation == ENCODER_ON_LOAD) ? "O TAI (TRUC TAM)" :
                      (encoderLocation == ENCODER_ON_MOTOR) ? "O TRUC MOTOR" : "CHUA XAC NHAN (UNKNOWN)",
                      getDegPerCount(), getPulsesPerCount());
        Serial.printf(" DS3231 INT (GPIO %2d): %s\n", DS3231_SQW_PIN, digitalRead(DS3231_SQW_PIN) ? "HIGH (Chua ngat)" : "LOW (Dang kich ngat)");
        printOpticalSensors();
        printRTCStatus();
        Serial.println("=======================================================\n");
        break;

      // PHÍM K: BẬT / TẮT STREAM MỨC LOGIC THÔ & ĐẾM CẠNH (200ms)
      case 'k': case 'K':
        rawEncStream = !rawEncStream;
        Serial.printf("\n>> [RAW ENCODER STREAM: %s] %s\n",
                      rawEncStream ? "ON" : "OFF",
                      rawEncStream ? "Dang in muc logic tho & so canh rieng Pha A/B moi 200ms... (Bam 'k' hoac go 'raw' de tat)" : "Da tat stream.");
        break;

      case 'r': case 'R': case '?':
        printMenu();
        break;

      default:
        break;
    }
    Serial.print("\n[CLI]> ");
  }

  // THEO DÕI LIVE ENCODER KHI BẬT CHẾ ĐỘ PHÍM V (PCNT HARDWARE COUNTS)
  static int32_t lastLiveCnt1 = 0, lastLiveCnt2 = 0;
  if (liveEncoderMonitor) {
    int32_t curC1 = getEncoderCount1();
    int32_t curC2 = getEncoderCount2();
    if (curC1 != lastLiveCnt1 || curC2 != lastLiveCnt2) {
      lastLiveCnt1 = curC1; lastLiveCnt2 = curC2;
      Serial.printf(">> [PCNT LIVE] M1(G%d,%d): %-5ld (%+5.1f°) | M2(G%d,%d): %-5ld (%+5.1f°)\n",
                    M1_ENC_A_PIN, M1_ENC_B_PIN, curC1, getAngleDeg1(),
                    M2_ENC_A_PIN, M2_ENC_B_PIN, curC2, getAngleDeg2());
    }
  }

  // B. XỬ LÝ CHẾ ĐỘ TỰ ĐỘNG BÁM THEO HƯỚNG ÁNH SÁNG (OPTICAL TRACKING) - HAI TRỤC ĐỒNG THỜI & NON-BLOCKING
  static unsigned long lastOpticalLogTime = 0;
  if (autoOpticalTracking) {
    if (millis() - lastOpticalTrackTime >= 100) { // Chu kỳ bám 100ms
      lastOpticalTrackTime = millis();
      OpticalData opt = readOpticalSensors();

      if (opt.avg < OPTICAL_NIGHT_THRESHOLD) {
        // Quá tối, không quay lung tung
        if (millis() - lastOpticalLogTime >= 3000) {
          lastOpticalLogTime = millis();
          Serial.printf(">> [OPTICAL TRACKING] Troi toi (AVG=%d < %d) -> Tam dung quay de tiet kiem nang luong.\n",
                        opt.avg, OPTICAL_NIGHT_THRESHOLD);
        }
        if (stepper1 && stepper1->isRunning()) stepper1->stopMove();
        if (stepper2 && stepper2->isRunning()) stepper2->stopMove();
      } else {
        bool m1Moved = false;
        bool m2Moved = false;

        // 1. Trục Azimuth: Điều khiển TỈ LỆ theo sai số chuẩn hóa normDiffAz
        float absErrAz = fabs(opt.normDiffAz);
        if (absErrAz > OPTICAL_NORM_DEADBAND) {
          if (stepper1 && !stepper1->isRunning()) {
            float errActiveAz = absErrAz - OPTICAL_NORM_DEADBAND; // Sai số ngoài vùng chết [0.0 .. ~0.95]

            // Tốc độ tỉ lệ: 800 Hz (lệch nhỏ) -> 5000 Hz (lệch lớn)
            uint32_t speedAz = (uint32_t)(800 + errActiveAz * 4500);
            if (speedAz > 5000) speedAz = 5000;

            // Số bước tỉ lệ: 50 bước (gần cân bằng) -> 640 bước (lệch lớn, ~3 độ)
            int32_t stepsAz = (int32_t)(50 + errActiveAz * 600);
            if (stepsAz > 640) stepsAz = 640;

            stepper1->setSpeedInHz(speedAz);
            stepper1->setAcceleration(stepperAccel);

            if (opt.normDiffAz > 0) {
              if (isHome1Triggered()) {
                if (millis() - lastOpticalLogTime >= 2000) {
                  lastOpticalLogTime = millis();
                  Serial.println(">> [TRACKING M1] Anh sang huong ve Home nhung da CHAM CTHT 1 -> Khoa!");
                }
              } else {
                stepper1->move(-stepsAz); // Chạy êm về Home theo tỉ lệ
                m1Moved = true;
              }
            } else {
              if (getAngleDeg1() >= CFG_I_AZ_MAX_SOFT_LIMIT_DEG) {
                if (millis() - lastOpticalLogTime >= 2000) {
                  lastOpticalLogTime = millis();
                  Serial.printf(">> [TRACKING M1] Da CHAM GIOI HAN MEM Tay (%+.1f°) -> Khoa chieu quay ra xa!\n", CFG_I_AZ_MAX_SOFT_LIMIT_DEG);
                }
              } else {
                stepper1->move(stepsAz); // Chạy êm ra xa Home theo tỉ lệ
                m1Moved = true;
              }
            }
          }
        } else {
          // Nằm trong vùng chết: dừng êm
          if (stepper1 && stepper1->isRunning()) stepper1->stopMove();
        }

        // 2. Trục Elevation: Điều khiển TỈ LỆ theo sai số chuẩn hóa normDiffEl - ĐỒNG THỜI
        float absErrEl = fabs(opt.normDiffEl);
        if (absErrEl > OPTICAL_NORM_DEADBAND) {
          if (stepper2 && !stepper2->isRunning()) {
            float errActiveEl = absErrEl - OPTICAL_NORM_DEADBAND;

            // Tốc độ tỉ lệ: 800 Hz -> 4500 Hz
            uint32_t speedEl = (uint32_t)(800 + errActiveEl * 3800);
            if (speedEl > 4500) speedEl = 4500;

            // Số bước tỉ lệ: 50 bước -> 500 bước (~2.3 độ)
            int32_t stepsEl = (int32_t)(50 + errActiveEl * 450);
            if (stepsEl > 500) stepsEl = 500;

            stepper2->setSpeedInHz(speedEl);
            stepper2->setAcceleration(stepperAccel);

            if (opt.normDiffEl > 0) {
              if (getElevationEpsilon() <= CFG_L_EL_MIN_SOFT_LIMIT_DEG) {
                if (millis() - lastOpticalLogTime >= 2000) {
                  lastOpticalLogTime = millis();
                  Serial.printf(">> [TRACKING M2] Da CHAM GIOI HAN MEM Ha Thap (%+.1f° - Chong can khung Z) -> Khoa!\n", CFG_L_EL_MIN_SOFT_LIMIT_DEG);
                }
              } else {
                stepper2->move(stepsEl); // Hạ thấp theo tỉ lệ
                m2Moved = true;
              }
            } else {
              if (isHome2Triggered() || getElevationEpsilon() >= CFG_J_EL_MAX_SOFT_LIMIT_DEG) {
                if (millis() - lastOpticalLogTime >= 2000) {
                  lastOpticalLogTime = millis();
                  Serial.printf(">> [TRACKING M2] Da CHAM GIOI HAN MEM Ngua (%+.1f°) hoac CTHT 2 -> Khoa!\n", CFG_J_EL_MAX_SOFT_LIMIT_DEG);
                }
              } else {
                stepper2->move(-stepsEl); // Ngửa lên về Home theo tỉ lệ
                m2Moved = true;
              }
            }
          }
        } else {
          // Nằm trong vùng chết: dừng êm
          if (stepper2 && stepper2->isRunning()) stepper2->stopMove();
        }

        if ((m1Moved || m2Moved) && (millis() - lastOpticalLogTime >= 800)) {
          lastOpticalLogTime = millis();
          Serial.printf(">> [PROPORTIONAL TRACK] dAZ=%+5.1f%% (%s) | dEL=%+5.1f%% (%s) | Goc: M1=%+.2f°, M2=%+.2f°\n",
                        opt.normDiffAz * 100.0f, (opt.normDiffAz > 0 ? "Vao Home" : "Ra xa"),
                        opt.normDiffEl * 100.0f, (opt.normDiffEl > 0 ? "Ngang len" : "Chui xuong"),
                        getAngleDeg1(), getAngleDeg2());
        }
      }
    }
  }

  // C. GIÁM SÁT AN TOÀN VÀ CÔNG TẮC HÀNH TRÌNH HOME & GIỚI HẠN MỀM CHO M1 & M2 (NON-BLOCKING)
  if (stepper1) {
    if (isHome1Triggered()) {
      if (stateM1 == STATE_MANUAL_TOWARD_HOME || (stepper1->isRunning() && (stepper1->rampState() & RAMP_DIRECTION_COUNT_DOWN))) {
        stepper1->forceStopAndNewPosition(0);
        resetEncoder1(0);
        stateM1 = STATE_IDLE;
        Serial.println("\n>> [HOME TRIGGER TRUC 1] Da cham CTHT 1 -> DUNG & SET GOC 0.0°!");
      }
    }
    // Giám sát giới hạn mềm cận trên trục 1 (phi >= 270.0°)
    if (getAngleDeg1() >= CFG_I_AZ_MAX_SOFT_LIMIT_DEG) {
      if (stateM1 == STATE_MANUAL_AWAY_HOME || (stepper1->isRunning() && (stepper1->rampState() & RAMP_DIRECTION_COUNT_UP))) {
        stepper1->stopMove();
        stateM1 = STATE_IDLE;
        Serial.printf("\n>> [GIOI HAN MEM TRUC 1] Phi = %+.1f° >= %+.1f° -> DUNG DE CHONG XOAN CAP!\n",
                      getAngleDeg1(), CFG_I_AZ_MAX_SOFT_LIMIT_DEG);
      }
    }
    if (stateM1 != STATE_IDLE && stateM1 != STATE_AUTO_HOMING && stateM1 != STATE_AUTO_SEEK_DEFAULT) {
      if (!stepper1->isRunning()) stateM1 = STATE_IDLE;
    }
  }

  if (stepper2) {
    if (isHome2Triggered()) {
      if (stateM2 == STATE_MANUAL_TOWARD_HOME || (stepper2->isRunning() && (stepper2->rampState() & RAMP_DIRECTION_COUNT_DOWN))) {
        stepper2->forceStopAndNewPosition(0);
        resetEncoder2(0);
        stateM2 = STATE_IDLE;
        Serial.println("\n>> [HOME TRIGGER TRUC 2] Da cham CTHT 2 -> DUNG & SET GOC 0.0°!");
      }
    }
    // Giám sát giới hạn mềm cận trên trục 2 (epsilon >= SOFT_MAX_EL)
    if (getElevationEpsilon() >= CFG_J_EL_MAX_SOFT_LIMIT_DEG) {
      if (stateM2 == STATE_MANUAL_AWAY_HOME || (stepper2->isRunning() && (stepper2->rampState() & RAMP_DIRECTION_COUNT_UP))) {
        stepper2->stopMove();
        stateM2 = STATE_IDLE;
        Serial.printf("\n>> [GIOI HAN MEM TRUC 2] Epsilon = %+.1f° >= %+.1f° -> DUNG DE CHONG QUA GOC!\n",
                      getElevationEpsilon(), CFG_J_EL_MAX_SOFT_LIMIT_DEG);
      }
    }
    // Giám sát giới hạn mềm cận dưới trục 2 (epsilon <= 25.0°)
    if (getElevationEpsilon() <= CFG_L_EL_MIN_SOFT_LIMIT_DEG) {
      if (stateM2 == STATE_MANUAL_AWAY_HOME || (stepper2->isRunning() && (stepper2->rampState() & RAMP_DIRECTION_COUNT_UP))) {
        stepper2->stopMove();
        stateM2 = STATE_IDLE;
        Serial.printf("\n>> [GIOI HAN MEM TRUC 2] Epsilon = %+.1f° <= %+.1f° -> DUNG DE CHONG CAN TRUC Z!\n",
                      getElevationEpsilon(), CFG_L_EL_MIN_SOFT_LIMIT_DEG);
      }
    }
    if (stateM2 != STATE_IDLE && stateM2 != STATE_AUTO_HOMING && stateM2 != STATE_AUTO_SEEK_DEFAULT) {
      if (!stepper2->isRunning()) stateM2 = STATE_IDLE;
    }
  }

  // C. IN DINH KY 200ms MUC LOGIC THO & SO SANH SONG SONG PCNT (HW) VS LOOKUP TABLE (SW)
  static unsigned long lastRawStreamMs = 0;
  if (rawEncStream && (millis() - lastRawStreamMs >= 200)) {
    lastRawStreamMs = millis();
    int32_t hwCnt1 = getEncoderCount1();
    int32_t hwCnt2 = getEncoderCount2();
    bool match1 = (hwCnt1 == swEncoderCount1);
    bool match2 = (hwCnt2 == swEncoderCount2);

    Serial.printf("[ENC1-AZ] A(G%2d): %d (eA:%5lu) | B(G%2d): %d (eB:%5lu) | HW:%6ld | SW:%6ld | %s\n",
                  M1_ENC_A_PIN, digitalRead(M1_ENC_A_PIN), rawEdges1A,
                  M1_ENC_B_PIN, digitalRead(M1_ENC_B_PIN), rawEdges1B,
                  hwCnt1, swEncoderCount1, match1 ? "MATCH (OK)" : "MISMATCH (!)");
    Serial.printf("[ENC2-EL] A(G%2d): %d (eA:%5lu) | B(G%2d): %d (eB:%5lu) | HW:%6ld | SW:%6ld | %s\n",
                  M2_ENC_A_PIN, digitalRead(M2_ENC_A_PIN), rawEdges2A,
                  M2_ENC_B_PIN, digitalRead(M2_ENC_B_PIN), rawEdges2B,
                  hwCnt2, swEncoderCount2, match2 ? "MATCH (OK)" : "MISMATCH (!)");
  }

}
